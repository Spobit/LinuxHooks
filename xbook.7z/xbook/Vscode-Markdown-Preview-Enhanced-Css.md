---
title: Vscode Markdown-Preview-Enhanced Css
categories:
  - it
  - HyperText
  - CssStyle
tags:
  - it
  - HyperText
  - CssStyle
date: 2019-04-14 19:27:09
---

``` {class=line-numbers}
/* Please visit the URL below for more information: */
/*   https://shd101wyy.github.io/markdown-preview-enhanced/#/customize-css */
/* ~/.mume/style.less */

.markdown-preview.markdown-preview {

    ///>
    /// spobit
    /// css for "markdown priveiw enhanced"

    ///> base
    background: #fff;
    border: 0px solid red !important;

    ///> hr
    hr {
        margin: 8px 0 !important;
        border: 0px solid red !important;
        padding: 0 !important;

        background-color: rgba(27, 36, 38, 1) !important;
        height: 2px !important;
        border-bottom: 1px solid #ddd !important;
        box-shadow: 0px 2px 2px #222 !important;
    }

    ///> h1, h2, h3, h4, h5, h6
    h1, h2, h3, h4, h5, h6 {
        /// margin border padding
        margin: 20px 0px !important;
        border: 0px solid red !important;
        border-left: 8px solid #f00 !important;
        border-top-left-radius: 4px !important;
        border-bottom-left-radius: 4px !important;
        padding: 0px !important;
        /// font
        font-family: "Fixedsys Excelsior 3.01" !important;
        font-size: 16px !important;
        font-style: normal !important;
        font-weight: normal !important;
        /// line-height
        line-height: 19.2px !important;
        /// color
        color: #000 !important;
        background: #fff;
    }

    h1{border-left-color: #f00 !important;}
    h2{border-left-color: #FF7F50 !important;}
    h3{border-left-color: #ff0 !important;}
    h4{border-left-color: #0f0 !important;}
    h5{border-left-color: #97FFFF !important;}
    h6{border-left-color: #00f !important;}

    h1 > code, h2 > code, h3 > code, h4 > code, h5 > code, h6 > code {
        /// margin border padding
        margin: 0px 0px !important;
        border: 0px  solid red !important;
        border-radius: 0px !important;
        border-top-right-radius: 4px !important;
        border-bottom-right-radius: 4px !important;
        padding: 1.5px 0px !important;
        /// font
        font-family: "Fixedsys Excelsior 3.01" !important;
        font-size: 16px !important;
        font-style: normal !important;
        font-weight: normal !important;
        /// line-height
        line-height: 19.2px !important;
        /// color
        color: #000 !important;
        background: #00f4;
    }

    ///> page
    p {
        /// margin border padding
        margin: 20px 0px !important;
        border: 0px  solid red !important;
        padding: 0px !important;
        /// font
        font-family: "Fixedsys Excelsior 3.01" !important;
        font-size: 16px !important;
        font-style: normal !important;
        font-weight: normal !important;
        /// line-height
        line-height: 19.2px !important;
        /// color
        color: #000 !important;
        background: #fff !important;
    }

    ///> pre code

    //"    "
    pre {
        /// margin border padding
        // margin: 20px 0px !important;
        // border: 0px  solid red !important;
        // padding: 0px !important;
        /// font
        // font-family: "Fixedsys Excelsior 3.01" !important;
        // font-size: 16px !important;
        // font-style: normal !important;
        // font-weight: normal !important;
        /// line-height
        line-height: 19.2px !important;
        /// color
        color: #000 !important;
        background: #eee;
    }

    // ```
    pre > code {
        /// margin border padding
        // margin: 20px 0px !important;
        // border: 0px  solid red !important;
        // padding: 0px !important;
        /// font
        font-family: "Fixedsys Excelsior 3.01" !important;
        font-size: 16px !important;
        font-style: normal !important;
        font-weight: normal !important;
        /// line-height
        line-height: 19.2px !important;
        /// color
        color: #000 !important;
        background: #fff0 !important;
    }

    // `
    code {
        /// margin border padding
        margin: 20px 0px !important;
        border: 0px  solid red !important;
        padding: 1.6px 0px !important;
        /// font
        font-family: "Fixedsys Excelsior 3.01" !important;
        font-size: 16px !important;
        font-style: normal !important;
        font-weight: normal !important;
        /// line-height
        line-height: 19.2px !important;
        /// color
        color: #000 !important;
        background: #00f4 !important;
    }

    ///> ol ul > li
    li {
        /// font
        font-family: "Fixedsys Excelsior 3.01" !important;
        font-size: 16px !important;
        font-style: normal !important;
        font-weight: normal !important;
        /// color
        color: #000 !important;
    }

    li > p, li > blockquote {
        margin: 8px 0px !important;
    }

    ///> table
    tr {
        line-height: 1rem !important;
    }

    th {
        border: none !important;
        /// margin border padding
        // margin: 20px 0px !important;
        border-top: 2px solid #404040c0 !important;
        border-bottom: 2px solid #404040c0 !important;
        // padding: 0px !important;
        /// font
        font-family: "Fixedsys Excelsior 3.01" !important;
        font-size: 16px !important;
        font-style: normal !important;
        font-weight: normal !important;
        text-align:left !important;
        /// line-height
        // line-height: 19.2px !important;
        /// color
        color: #000 !important;
        // background: #fff;
    }

    td {
        /// margin border padding
        // margin: 20px 0px !important;
        border: none !important;
        border-bottom: 1px solid #d6d6d6 !important;
        // padding: 0px !important;
        /// font
        font-family: "Fixedsys Excelsior 3.01" !important;
        font-size: 16px !important;
        font-style: normal !important;
        font-weight: normal !important;
        /// line-height
        // line-height: 19.2px !important;
        /// color
        color: #000 !important;
        // background: #fff;
    }

    ///> blockquote
    blockquote {
        background: #eee !important;;
    }
    blockquote > p {
        background: #fff0 !important;;
        margin: 8px 0px !important;
    }

    ///> Cpp
    cpptype {
        color: #00f !important;
        font-weight: bold !important;
    }
    cppvar {
        color: #00f !important;
    }
    cppfun {
        color: #0aa !important;
    }
    cpparg {
        color: #f00 !important;
    }
}
```