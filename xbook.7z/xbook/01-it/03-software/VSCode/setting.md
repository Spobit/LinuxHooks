```
{
    "files.associations": {
      "qobject": "cpp"
    },
    "editor.fontSize": 16,
    "editor.fontFamily": "Fixedsys Excelsior 3.01",
    "editor.codeLens": false,
    "editor.cursorStyle": "line-thin",
    "files.autoSave": "onFocusChange",
    "editor.hover.delay": 100,
    "editor.lineHeight": 18,
    "editor.formatOnType": true,
    "editor.minimap.enabled": false,
    "editor.mouseWheelZoom": true,
    "editor.renderControlCharacters": true,
    "editor.showFoldingControls": "always",
    "files.trimFinalNewlines": true,
    "workbench.activityBar.visible": false,
    "C_Cpp.intelliSenseEngineFallback": "Disabled",
    "editor.wordWrap": "off",
    "editor.rulers": [ 80, 82 ],
    "files.trimTrailingWhitespace": true
}
```