AddDir:
  \- C:\_App\Qt\5.12.1\Src\qtbase\src
  \- C:\_App\Qt\5.12.1\msvc2017\include