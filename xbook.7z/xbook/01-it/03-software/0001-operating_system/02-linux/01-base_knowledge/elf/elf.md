---
title: elf
categories:
  - unknown
tags:
  - unknown
date: 2019-04-14 15:29:11
---

`定义`

`作用`

`位置 尺寸 数量`

`解释`

`注意`

***
[TOC]
***

# `In A Nutshell`

[ELF](#elf)是一种存储格式.它详细的指出数据在文件中,在内存是如何存放与使用.最终使之被使用或被执行.

# `Conception`

# `Details`

# `Verbose`

## `Categorize`

- relocatable object:
  holds sections containing code and data; This file is suitable to be linked with other relocatable object files to create dynamic executable files, shared object files, or another relocatable object;

- shared object:
  holds code and data that is suitable for additional linking; The link-editor can process this file with other relocatable object files and/or shared object files to create other object files;

- dynamic executable:
  holds a program that is ready to execute; The file specifies how exec(2) creates a program's process image; This file is typically bound to shared object files at runtime to create a process image; The runtime linker combines this file with a dynamic executable file and other shared object files to create a process image;

## `Organize`

| Linking View | Execution View |
|---|---|
| ELF header                      | ELF header |
| Program header table (optional) | Program header table |
| Section 1                       | Segment 1 |
| ...                             | Segment 2 |
| Section n                       | ... |
| ...                             | ... |
| ...                             | ... |
| Section header table            | Section header table (optional) |

**ELF header** resides at the beginning of an object file and holds a road map describing the file's organization.

**Note:** Only the ELF header has a fixed position in the file. The flexibility of the ELF format requires no specified order for header tables, sections or segments. However, this figure is typical of the layout used in the Oracle Solaris OS.

**Sections** represent the smallest indivisible units that can be processed within an ELF file.

Sections hold the bulk of object file information for the linking view. This data includes instructions, data, symbol table, and relocation information.
Descriptions of sections appear in the first part of this chapter. The second part of this chapter discusses segments and the program execution view of the file.

**Section header table** contains information describing the file's sections. Every section has an entry in the table. Each entry gives information such as the section name and section size. Files that are used in link-editing must have a section header table.

**Segments** are a collection of sections. Segments represent the smallest individual units that can be mapped to a memory image by exec(2) or by the runtime linker.

**Program header table**, if present, tells the system how to create a process image. Files used to generate a process image, executable files and shared objects, must have a program header table. Relocatable object files do not need a program header table.

## `Data Representation`

The object file format supports various processors with 8-bit bytes, 32–bit architectures and 64–bit architectures. Nevertheless, the data representation is intended to be extensible to larger, or smaller, architectures.

**Table ELF 32–Bit Data Types:**

| Name | Size | Alignment | Purpose |
|---|---|---|---|
| Elf32_Addr    | 4 | 4 | Unsigned program address |
| Elf32_Half    | 2 | 2 | Unsigned medium integer |
| Elf32_Off     | 4 | 4 | Unsigned file offset |
| Elf32_Sword   | 4 | 4 | Signed integer |
| Elf32_Word    | 4 | 4 | Unsigned integer |
| unsigned char | 1 | 1 | Unsigned small integer |

**Table ELF 64–Bit Data Types:**

| Name | Size | Alignment | Purpose |
|---|---|---|---|
| Elf64_Addr    | 8 | 8 | Unsigned program address |
| Elf64_Half    | 2 | 2 | Unsigned medium integer |
| Elf64_Off     | 8 | 8 | Unsigned file offset |
| Elf64_Sword   | 4 | 4 | Signed integer |
| Elf64_Word    | 4 | 4 | Unsigned integer |
| Elf64_Xword   | 8 | 8 | Unsigned long integer |
| Elf64_Sxword  | 8 | 8 | Signed long integer |
| unsigned char | 1 | 1 | Unsigned small integer |

## `EFL Header`

Some control structures within object files can grow because the ELF header
contains their actual sizes. If the object file format does change, a program
can encounter control structures that are larger or smaller than expected.
Programs might therefore ignore extra information. The treatment of missing
information depends on context and is specified if and when extensions are
defined.

**EFL header** is a structure what is Elf632_Ehdr/Elf64_Ehdr.

## `Sections`

**Sections** hold the bulk of object file information for the linking view. This
data includes instructions, data, symbol table, and relocation information.
Descriptions of sections appear in the first part of this chapter. The second
part of this chapter discusses segments and the program execution view of the
file.

Sections represent the smallest indivisible units that can be processed
within an ELF file.

## `Section Header`

**Section header** is a structure what is Elf32_Shdr/Elf64_Shdr, it gives some
informations for suitable section. Every section has an section header in the
table.

## `Section Header Table`

`定义`

Elf64_Ehdr::e_shoff指出的文件块,被称为Section Header Table.

`作用`

保存所有的Section Header信息.

`位置 尺寸 数量`

Elf64_Ehdr::e_shoff给出了在文件中位置.

Elf64_Ehdr::e_ehsize给出了在文件中尺寸.

没有或有一个.

`解释`

由[Elf64_Shdr](#elf64_shdr)结构组成的数组.元素尺寸由Elf64_Shdr::e_shentsize指出.元素个数由Elf64_Ehdr::e_shnum指出.

`注意`

***

**Section header table** of object file allows you to locate all of the sections
of the file. The section header table is an array of Elf32_Shdr or Elf64_Shdr
structures, a section header table index is a subscript into this array.

Files that are used in link-editing must have a section header table.

**Elf64_Shdr::e_shoff** member indicates the byte offset from the beginning of
the file to the section header table.

**Elf64_Shdr::e_shnum** member indicates how many entries that the section
header table contains.

**Elf64_Shdr::e_shentsize** member indicates the size in bytes of each entry.

**Note:** If the number of sections is greater than or equal to SHN_LORESERVE
(0xff00), e_shnum has the value SHN_UNDEF (0). The actual number of section
header table entries is contained in the sh_size field of the section header
at index 0. Otherwise, the sh_size member of the initial entry contains the
value zero.

Some section header table indexes are reserved in contexts where index size is
restricted. For example, the st_shndx member of a symbol table entry and the
e_shnum and e_shstrndx members of the ELF header. In such contexts, the reserved
values do not represent actual sections in the object file. Also in such
contexts, an escape value indicates that the actual section index is to be found
elsewhere, in a larger field.

# `Parallel Universe`

## `Global Offset Table`

`定义`

符号名为\_GLOBAL\_OFFSET\_TABLE\_的数组是Global Offset Table.

`作用`

 The runtime linker determines the absolute addresses of the destinations and modifies the global offset table's memory image accordingly.

保存导入函数与全局变量的地址表.与PLT配合,完成重定位.

GOT是导入函数与全局变量的地址表,当然前三个它用.开始的时候调用导入函数是到对应的PLT条目中,PLT会调用GOT里的函数地址,不过在开始的时候,GOT条目地址指向了PTL条目的下一条指令,然后PTL条目压入GOT条目索引,再调用GOT[2]处,它是_dl_runtime_resolve函数,它能找到真实的函数地址,然后修复这个GOT条目,调用函数;这样,下次到PTL条目后,再次调用GOT条目,就调用了真实的函数了.

`位置 尺寸 数量`

- 位置:

  ``` {class=line-numbers}
  readelf -s ./main | grep OFF
      51: 0000000000601000     0 OBJECT  LOCAL  DEFAULT   24 _GLOBAL_OFFSET_TABLE_

  readelf -S ./main | grep 601000
    [24] .got.plt          PROGBITS         0000000000601000  00001000
  ```

- 尺寸:

  节头的Elf64_Shdr::sh_size指出尺寸.

- 数量:

  最多一个.

`解释`

GOT保存着运行时要重定位的函数地址的数组.当然,前三个位置有特有的数据.
\_GLOBAL_OFFSET\_TABLE\_[0] == _DYNAMIC.
\_GLOBAL\_OFFSET\_TABLE\_[1] == struct link_map* l链,记录已经加载的共享对象的信息.
\_GLOBAL\_OFFSET\_TABLE\_[2] == _dl_runtime_resolve函数 in /lib/x86_64-linux-gnu/ld-2.23.so.
GOT[0]是\_DYNAMIC表;GOT[1]保存了已经加载的共享库的信息.这样,如果一个库被加载了,可以用它找到函数真正的地址,如果没有找到,就要加载库后再查找,当然,这个被加载的库也会链到GOT[1]链接中;GOT[2]是_dl_runtime_resolve函数地址,它是找到函数地址功能的代码实现.

GOT的数据结构为:

``` {class=line-numbers}
extern  Elf32_Addr  _GLOBAL_OFFSET_TABLE_[];
extern  Elf64_Addr  _GLOBAL_OFFSET_TABLE_[];
```

`注意`

运行时链接器解决符号引用的过程:

1. 在程序镜像被运行时链接器初始创建后,运行时链接器修改GOT[1]与GOT[2]为特定的值.

2. 进程中的每个共享对象有自己的PLT,且控制只能从对象文件自身传输到自身的PLT条目.

3. For example, the program calls name1, which transfers control to the label .PLT1.

The following steps describe how the runtime linker and program cooperate to resolve the symbolic references through the procedure linkage table and the global offset table.

- When the memory image of the program is initially created, the runtime linker sets the second and third entries in the global offset table to special values. The following steps explain these values.

- Each shared object file in the process image has its own procedure linkage table, and control transfers to a procedure linkage table entry only from within the same object file.

- For example, the program calls name1, which transfers control to the label .PLT1.

- The first instruction jumps to the address in the global offset table entry for name1. Initially, the global offset table holds the address of the following pushq instruction, not the real address of name1.

- The program pushes a relocation index (index1) on the stack. The relocation offset is a 32–bit, nonnegative index into the relocation table. The relocation table is identified by the DT_JUMPREL dynamic section entry. The designated relocation entry has the type R_AMD64_JMP_SLOT, and its offset specifies the global offset table entry used in the previous jmp instruction. The relocation entry also contains a symbol table index, which the runtime linker uses to get the referenced symbol, name1.

- After pushing the relocation index, the program jumps to .PLT0, the first entry in the procedure linkage table. The pushq instruction pushes the value of the second global offset table entry (GOT+8) on the stack, giving the runtime linker one word of identifying information. The program then jumps to the address in the third global offset table entry (GOT+16), to jump to the runtime linker.

- The runtime linker unwinds the stack, checks the designated relocation entry, gets the symbol's value, stores the actual address of name1 in its global offset entry table, and jumps to the destination.

- Subsequent executions of the procedure linkage table entry transfer directly to name1, without calling the runtime linker again. The jmp instruction at .PLT1 jumps to name1 instead of falling through to the pushq instruction.

***

``` {class=line-numbers}
extern Elf64_Addr _GLOBAL_OFFSET_TABLE_[];

readelf -s ./main | grep _GLOBAL_OFFSET_TABLE_
    51: 0000000000601000     0 OBJECT  LOCAL  DEFAULT   24 _GLOBAL_OFFSET_TABLE_
```

_GLOBAL_OFFSET_TABLE_[0] == _DYNAMIC.
_GLOBAL_OFFSET_TABLE_[1] == struct link_map*变量,一个链,记录已经加载的共享对象的信息.
_GLOBAL_OFFSET_TABLE_[2] == /lib/x86_64-linux-gnu/ld-2.23.so _dl_runtime_resolve()
_GLOBAL_OFFSET_TABLE_[3] == puts
_GLOBAL_OFFSET_TABLE_[4] == __libc_start_main
_GLOBAL_OFFSET_TABLE_[5] == fopen

找到 *Elf64_Shdr*::*sh_addr* 是0x601000的节头,指向的节就是got了:

``` {class=line-numbers}
$ readelf -S ./main | grep 601000
  [24] .got.plt          PROGBITS         0000000000601000  00001000

$ readelf -S ./main
Section Headers:
  [Nr] Name              Type             Address           Offset
       Size              EntSize          Flags  Link  Info  Align
  [24] .got.plt          PROGBITS         0000000000601000  00001000
       0000000000000030  0000000000000008  WA       0     0     8
```


got表在文件中:

``` {class=line-numbers}
$ hexdump -C -s0x1000 -n48 ./main
00001000  28 0e 60 00 00 00 00 00  00 00 00 00 00 00 00 00
00001010  00 00 00 00 00 00 00 00  36 04 40 00 00 00 00 00
00001020  46 04 40 00 00 00 00 00  56 04 40 00 00 00 00 00
```

got表在内存中:

``` {class=line-numbers}
(gdb) x/48xb 0x601000
0x601000: 28 0e 60 00 00 00 00 00  68 e1 ff f7 ff 7f 00 00
0x601010: a0 e6 de f7 ff 7f 00 00  36 04 40 00 00 00 00 00
0x601020: c0 c7 81 f7 ff 7f 00 00  56 04 40 00 00 00 00 00

(gdb) x/6xg 0x601000
0x601000: 0x0000000000600e28  0x00007ffff7ffe168
0x601010: 0x00007ffff7dee6a0  0x0000000000400436
0x601020: 0x00007ffff781c7c0  0x0000000000400456
```

## `Procedure Linkage Table`

`定义`

`作用`

`位置 尺寸 数量`

`解释`

`注意`

For x64 dynamic objects, the procedure linkage table resides in shared text but uses addresses in the private global offset table.

***

名称为.plt的节头所指向节为.plt节,它的内容是plt表.

plt表在文件中:

``` {class=line-numbers}
$ hexdump -C -s0x420 -n64 ./main
00000420  ff 35 e2 0b 20 00 ff 25  e4 0b 20 00 0f 1f 40 00
00000430  ff 25 e2 0b 20 00 68 00  00 00 00 e9 e0 ff ff ff
00000440  ff 25 da 0b 20 00 68 01  00 00 00 e9 d0 ff ff ff
00000450  ff 25 d2 0b 20 00 68 02  00 00 00 e9 c0 ff ff ff
```

plt表在内存中:

``` {class=line-numbers}
$ objdump -d ./main

Disassembly of section .plt:

0000000000400420 <puts@plt-0x10>:
  400420: ff 35 e2 0b 20 00     pushq  0x200be2(%rip)         # 601008 <_GLOBAL_OFFSET_TABLE_+0x8>
  400426: ff 25 e4 0b 20 00     jmpq   *0x200be4(%rip)        # 601010 <_GLOBAL_OFFSET_TABLE_+0x10>
  40042c: 0f 1f 40 00           nopl   0x0(%rax)

0000000000400430 <puts@plt>:
  400430: ff 25 e2 0b 20 00     jmpq   *0x200be2(%rip)        # 601018 <_GLOBAL_OFFSET_TABLE_+0x18>
  400436: 68 00 00 00 00        pushq  $0x0                   // 0 1 2 定义作用,所以这里是下标3
  40043b: e9 e0 ff ff ff        jmpq   400420 <_init+0x20>

0000000000400440 <__libc_start_main@plt>:
  400440: ff 25 da 0b 20 00     jmpq   *0x200bda(%rip)        # 601020 <_GLOBAL_OFFSET_TABLE_+0x20>
  400446: 68 01 00 00 00        pushq  $0x1                   // 0 1 2 定义作用,所以这里是下标4
  40044b: e9 d0 ff ff ff        jmpq   400420 <_init+0x20>

0000000000400450 <fopen@plt>:
  400450: ff 25 d2 0b 20 00     jmpq   *0x200bd2(%rip)        # 601028 <_GLOBAL_OFFSET_TABLE_+0x28>
  400456: 68 02 00 00 00        pushq  $0x2                   // 0 1 2 定义作用,所以这里是下标5
  40045b: e9 c0 ff ff ff        jmpq   400420 <_init+0x20>
```

``` {class=line-numbers}

<_dl_runtime_resolve_wrapper>
pushq   _GLOBAL_OFFSET_TABLE_[1]
jmpq    _GLOBAL_OFFSET_TABLE_[2]
nopl

<puts@plt>
jmpq    _GLOBAL_OFFSET_TABLE_[n]
pushq   <n-2>
jmpq    _dl_runtime_resolve_wrapper

<__libc_start_main@plt>
jmpq    _GLOBAL_OFFSET_TABLE_[n]
pushq   <n-2>
jmpq    _dl_runtime_resolve_wrapper

<fopen@plt>
jmpq    _GLOBAL_OFFSET_TABLE_[n]
pushq   <n-2>
jmpq    _dl_runtime_resolve_wrapper
```

## `Elf64_Ehdr::e_ident`

ELF provides an object file framework to support multiple processors, multiple data encoding, and multiple classes of machines. To support this object file family, the initial bytes of the file specify how to interpret the file. These bytes are independent of the processor on which the inquiry is made and independent of the file's remaining contents.

Elf64_Ehdr::e_ident has some array subcript, known as ELF Identification Index, detail see ELF Identification Index.

## `Analyze Section`

### `Section Header String Table Section`

`定义`

Elf64_Ehdr::e_shstrndx与Section Header Table指出的Section Header, 被称为Section Header String Table Section Header.

Section Header String Table Section Header指向的节,被称为Section Header String Table Section.

`作用`

保存所有节名的信息.

`位置 尺寸 数量`

Section Header String Table Section Header指出位置.

Section Header String Table Section Header指出尺寸.

没有或有一个.

`解释`

null结束的字符串集.保存着节名字符串集.

`注意`

***

节头字符串表节头指出节位置.节内容是节名称的字符串集合.

``` {class=line-numbers}
$ readelf -h ./main
ELF Header:
  Magic:   7f 45 4c 46 02 01 01 00 00 00 00 00 00 00 00 00
  Class:                             ELF64
  Data:                              2's complement, little endian
  Version:                           1 (current)
  OS/ABI:                            UNIX - System V
  ABI Version:                       0
  Type:                              EXEC (Executable file)
  Machine:                           Advanced Micro Devices X86-64
  Version:                           0x1
  Entry point address:               0x400470
  Start of program headers:          64 (bytes into file)
  Start of section headers:          7376 (bytes into file)
  Flags:                             0x0
  Size of this header:               64 (bytes)
  Size of program headers:           56 (bytes)
  Number of program headers:         9
  Size of section headers:           64 (bytes)
  Number of section headers:         36
  Section header string table index: 33
```

``` {class=line-numbers}
readelf -S ./main
There are 36 section headers, starting at offset 0x1cd0:

Section Headers:
  [Nr] Name              Type             Address           Offset
       Size              EntSize          Flags  Link  Info  Align
  [ 0]                   NULL             0000000000000000  00000000
       0000000000000000  0000000000000000           0     0     0
  [ 1] .interp           PROGBITS         0000000000400238  00000238
       000000000000001c  0000000000000000   A       0     0     1
  [33] .shstrtab         STRTAB           0000000000000000  00001b7e
       000000000000014c  0000000000000000           0     0     1
  [35] .strtab           STRTAB           0000000000000000  00001958
       0000000000000226  0000000000000000           0     0     1
```

索引是33,所以偏移是0x1b7c,尺寸是0x14c,节头字符串表节的内容为:

``` {class=line-numbers}
$ hexdump -C -s 0x1b7e -n 332 ./main
00001b7e  00 2e 73 79 6d 74 61 62  00 2e 73 74 72 74 61 62  |..symtab..strtab|
00001b8e  00 2e 73 68 73 74 72 74  61 62 00 2e 69 6e 74 65  |..shstrtab..inte|
00001b9e  72 70 00 2e 6e 6f 74 65  2e 41 42 49 2d 74 61 67  |rp..note.ABI-tag|
00001bae  00 2e 6e 6f 74 65 2e 67  6e 75 2e 62 75 69 6c 64  |..note.gnu.build|
00001bbe  2d 69 64 00 2e 67 6e 75  2e 68 61 73 68 00 2e 64  |-id..gnu.hash..d|
00001bce  79 6e 73 79 6d 00 2e 64  79 6e 73 74 72 00 2e 67  |ynsym..dynstr..g|
00001bde  6e 75 2e 76 65 72 73 69  6f 6e 00 2e 67 6e 75 2e  |nu.version..gnu.|
00001bee  76 65 72 73 69 6f 6e 5f  72 00 2e 72 65 6c 61 2e  |version_r..rela.|
00001bfe  64 79 6e 00 2e 72 65 6c  61 2e 70 6c 74 00 2e 69  |dyn..rela.plt..i|
00001c0e  6e 69 74 00 2e 70 6c 74  2e 67 6f 74 00 2e 74 65  |nit..plt.got..te|
00001c1e  78 74 00 2e 66 69 6e 69  00 2e 72 6f 64 61 74 61  |xt..fini..rodata|
00001c2e  00 2e 65 68 5f 66 72 61  6d 65 5f 68 64 72 00 2e  |..eh_frame_hdr..|
00001c3e  65 68 5f 66 72 61 6d 65  00 2e 69 6e 69 74 5f 61  |eh_frame..init_a|
00001c4e  72 72 61 79 00 2e 66 69  6e 69 5f 61 72 72 61 79  |rray..fini_array|
00001c5e  00 2e 6a 63 72 00 2e 64  79 6e 61 6d 69 63 00 2e  |..jcr..dynamic..|
00001c6e  67 6f 74 2e 70 6c 74 00  2e 64 61 74 61 00 2e 62  |got.plt..data..b|
00001c7e  73 73 00 2e 63 6f 6d 6d  65 6e 74 00 2e 64 65 62  |ss..comment..deb|
00001c8e  75 67 5f 61 72 61 6e 67  65 73 00 2e 64 65 62 75  |ug_aranges..debu|
00001c9e  67 5f 69 6e 66 6f 00 2e  64 65 62 75 67 5f 61 62  |g_info..debug_ab|
00001cae  62 72 65 76 00 2e 64 65  62 75 67 5f 6c 69 6e 65  |brev..debug_line|
00001cbe  00 2e 64 65 62 75 67 5f  73 74 72 00              |..debug_str.|
```

给出索引 0 1 33 35 四个节头实例:

``` {class=line-numbers}
$ hexdump -C -s 7376+64 -n 64 ./main
00001cd0  00 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
*
00001d10

$ hexdump -C -s 7440 -n 64 ./main
00001d10  1b 00 00 00 01 00 00 00  02 00 00 00 00 00 00 00  |................|
00001d20  38 02 40 00 00 00 00 00  38 02 00 00 00 00 00 00  |8.@.....8.......|
00001d30  1c 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00001d40  01 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00001d50

$ hexdump -C -s 9488 -n 64 ./main
00002510  11 00 00 00 03 00 00 00  00 00 00 00 00 00 00 00  |................|
00002520  00 00 00 00 00 00 00 00  7e 1b 00 00 00 00 00 00  |........~.......|
00002530  4c 01 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |L...............|
00002540  01 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
00002550

$ hexdump -C -s 9616 -n 64 ./main
00002590  09 00 00 00 03 00 00 00  00 00 00 00 00 00 00 00  |................|
000025a0  00 00 00 00 00 00 00 00  58 19 00 00 00 00 00 00  |........X.......|
000025b0  26 02 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |&...............|
000025c0  01 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00  |................|
000025d0
```

可以知道各节名称在节头字符串表中的 0x0 0x1b 0x11 0x09 偏移处,所以:

``` {class=line-numbers}
$ hexdump -C -s 7038 -n 20 ./main
00001b7e  00 2e 73 79 6d 74 61 62  00 2e 73 74 72 74 61 62  |..symtab..strtab|
00001b8e  00 2e 73 68                                       |..sh|
00001b92

$ hexdump -C -s 7065 -n 20 ./main
00001b99  2e 69 6e 74 65 72 70 00  2e 6e 6f 74 65 2e 41 42  |.interp..note.AB|
00001ba9  49 2d 74 61                                       |I-ta|
00001bad

$ hexdump -C -s 7055 -n 20 ./main
00001b8f  2e 73 68 73 74 72 74 61  62 00 2e 69 6e 74 65 72  |.shstrtab..inter|
00001b9f  70 00 2e 6e                                       |p..n|
00001ba3

$ hexdump -C -s 7047 -n 20 ./main
00001b87  2e 73 74 72 74 61 62 00  2e 73 68 73 74 72 74 61  |.strtab..shstrta|
00001b97  62 00 2e 69                                       |b..i|
00001b9b
```

### `String Table Section`

`定义`

当Elf64_Shdr*::*sh_type是SHT_STRTAB|SHT_DYNSTR时,这个节头指向的节为String Table Section.

`作用`

保存字符串集.

`位置 尺寸 数量`

SHT_STRTAB|SHT_DYNSTR类型的节头指出位置.

SHT_STRTAB|SHT_DYNSTR类型的节头指出尺寸.

不给出.

`解释`

null结束的字符串集.

`注意`

***

当 *Elf64_Shdr*::*sh_type* 是 SHT_STRTAB | SHT_DYNSTR 时,这个节头指向的节为字符串表节.

> String table sections hold null-terminated character sequences, commonly called strings. The object file uses these strings to represent symbol and section names. You reference a string as an index into the string table section.
>
> String Table Section 保存着null结束的字符序列,通常称作字符串.对象文件使用这些字符串表示符号各节的名称.其它地方用 String Table Section 索引的方式引用字符串.
>
> The first byte, which is index zero, holds a null character. Likewise, a string table's last byte holds a null character, ensuring null termination for all strings. A string whose index is zero specifies either no name or a null name, depending on the context.
>
> 第一个字节,最一个字符,保存null字符,确保所有字符串以null结束.索引为0的字符串是没有名字或空名字,依赖于上下文.
>
> An empty string table section is permitted. The section header's sh_size member contains zero. Nonzero indexes are invalid for an empty string table.
>
> 一个空的 String Table Section 是被允许的. *sh_size*将是零.对于空的 String Table Section 非零索引是无效的.
>
> A section header's sh_name member holds an index into the section header string table section. The section header string table is designated by the e_shstrndx member of the ELF header. The following figure shows a string table with 25 bytes and the strings associated with various indexes.
>
> *sh_name* 保存着 Section Header String Table Section 的索引. Section Header String Table 是被 *e_shstrndx* 指出.
>
> A string table index can refer to any byte in the section. A string can appear more than once. References to substrings can exist. A single string can be referenced multiple times. Unreferenced strings also are allowed.
>
> 字符串表索引可以引用 Section Header String Table Section 的任何位置. 字符串可以出现多少. 引用子字符串是可行的.一个字符串可以被引用多次.未引用的字符串就是被允许的.


找出 SHT_STRTAB 类型的节头表:

``` {class=line-numbers}
$ readelf -S ./main
There are 36 section headers, starting at offset 0x1cd0:

Section Headers:
  [Nr] Name              Type             Address           Offset
       Size              EntSize          Flags  Link  Info  Align
  [ 6] .dynstr           STRTAB           0000000000400330  00000330
       0000000000000043  0000000000000000   A       0     0     1
  [33] .shstrtab         STRTAB           0000000000000000  00001b7e
       000000000000014c  0000000000000000           0     0     1
  [35] .strtab           STRTAB           0000000000000000  00001958
       0000000000000226  0000000000000000           0     0     1
```

节头内容:

``` {class=line-numbers}
$ hexdump -C -s 0x330 -n 67 ./main
00000330  00 6c 69 62 63 2e 73 6f  2e 36 00 66 6f 70 65 6e  |.libc.so.6.fopen|
00000340  00 70 75 74 73 00 5f 5f  6c 69 62 63 5f 73 74 61  |.puts.__libc_sta|
00000350  72 74 5f 6d 61 69 6e 00  5f 5f 67 6d 6f 6e 5f 73  |rt_main.__gmon_s|
00000360  74 61 72 74 5f 5f 00 47  4c 49 42 43 5f 32 2e 32  |tart__.GLIBC_2.2|
00000370  2e 35 00                                          |.5.|
00000373

$ hexdump -C -s 0x1b7e -n 332 ./main
00001b7e  00 2e 73 79 6d 74 61 62  00 2e 73 74 72 74 61 62  |..symtab..strtab|
00001b8e  00 2e 73 68 73 74 72 74  61 62 00 2e 69 6e 74 65  |..shstrtab..inte|
00001b9e  72 70 00 2e 6e 6f 74 65  2e 41 42 49 2d 74 61 67  |rp..note.ABI-tag|
00001bae  00 2e 6e 6f 74 65 2e 67  6e 75 2e 62 75 69 6c 64  |..note.gnu.build|
00001bbe  2d 69 64 00 2e 67 6e 75  2e 68 61 73 68 00 2e 64  |-id..gnu.hash..d|
00001bce  79 6e 73 79 6d 00 2e 64  79 6e 73 74 72 00 2e 67  |ynsym..dynstr..g|
00001bde  6e 75 2e 76 65 72 73 69  6f 6e 00 2e 67 6e 75 2e  |nu.version..gnu.|
00001bee  76 65 72 73 69 6f 6e 5f  72 00 2e 72 65 6c 61 2e  |version_r..rela.|
00001bfe  64 79 6e 00 2e 72 65 6c  61 2e 70 6c 74 00 2e 69  |dyn..rela.plt..i|
00001c0e  6e 69 74 00 2e 70 6c 74  2e 67 6f 74 00 2e 74 65  |nit..plt.got..te|
00001c1e  78 74 00 2e 66 69 6e 69  00 2e 72 6f 64 61 74 61  |xt..fini..rodata|
00001c2e  00 2e 65 68 5f 66 72 61  6d 65 5f 68 64 72 00 2e  |..eh_frame_hdr..|
00001c3e  65 68 5f 66 72 61 6d 65  00 2e 69 6e 69 74 5f 61  |eh_frame..init_a|
00001c4e  72 72 61 79 00 2e 66 69  6e 69 5f 61 72 72 61 79  |rray..fini_array|
00001c5e  00 2e 6a 63 72 00 2e 64  79 6e 61 6d 69 63 00 2e  |..jcr..dynamic..|
00001c6e  67 6f 74 2e 70 6c 74 00  2e 64 61 74 61 00 2e 62  |got.plt..data..b|
00001c7e  73 73 00 2e 63 6f 6d 6d  65 6e 74 00 2e 64 65 62  |ss..comment..deb|
00001c8e  75 67 5f 61 72 61 6e 67  65 73 00 2e 64 65 62 75  |ug_aranges..debu|
00001c9e  67 5f 69 6e 66 6f 00 2e  64 65 62 75 67 5f 61 62  |g_info..debug_ab|
00001cae  62 72 65 76 00 2e 64 65  62 75 67 5f 6c 69 6e 65  |brev..debug_line|
00001cbe  00 2e 64 65 62 75 67 5f  73 74 72 00              |..debug_str.|
00001cca

$ hexdump -C -s 0x1958 -n 550 ./main
00001958  00 63 72 74 73 74 75 66  66 2e 63 00 5f 5f 4a 43  |.crtstuff.c.__JC|
00001968  52 5f 4c 49 53 54 5f 5f  00 64 65 72 65 67 69 73  |R_LIST__.deregis|
00001978  74 65 72 5f 74 6d 5f 63  6c 6f 6e 65 73 00 5f 5f  |ter_tm_clones.__|
00001988  64 6f 5f 67 6c 6f 62 61  6c 5f 64 74 6f 72 73 5f  |do_global_dtors_|
00001998  61 75 78 00 63 6f 6d 70  6c 65 74 65 64 2e 37 35  |aux.completed.75|
000019a8  38 35 00 5f 5f 64 6f 5f  67 6c 6f 62 61 6c 5f 64  |85.__do_global_d|
000019b8  74 6f 72 73 5f 61 75 78  5f 66 69 6e 69 5f 61 72  |tors_aux_fini_ar|
000019c8  72 61 79 5f 65 6e 74 72  79 00 66 72 61 6d 65 5f  |ray_entry.frame_|
000019d8  64 75 6d 6d 79 00 5f 5f  66 72 61 6d 65 5f 64 75  |dummy.__frame_du|
000019e8  6d 6d 79 5f 69 6e 69 74  5f 61 72 72 61 79 5f 65  |mmy_init_array_e|
000019f8  6e 74 72 79 00 6d 61 69  6e 2e 63 00 5f 5f 46 52  |ntry.main.c.__FR|
00001a08  41 4d 45 5f 45 4e 44 5f  5f 00 5f 5f 4a 43 52 5f  |AME_END__.__JCR_|
00001a18  45 4e 44 5f 5f 00 5f 5f  69 6e 69 74 5f 61 72 72  |END__.__init_arr|
00001a28  61 79 5f 65 6e 64 00 5f  44 59 4e 41 4d 49 43 00  |ay_end._DYNAMIC.|
00001a38  5f 5f 69 6e 69 74 5f 61  72 72 61 79 5f 73 74 61  |__init_array_sta|
00001a48  72 74 00 5f 5f 47 4e 55  5f 45 48 5f 46 52 41 4d  |rt.__GNU_EH_FRAM|
00001a58  45 5f 48 44 52 00 5f 47  4c 4f 42 41 4c 5f 4f 46  |E_HDR._GLOBAL_OF|
00001a68  46 53 45 54 5f 54 41 42  4c 45 5f 00 5f 5f 6c 69  |FSET_TABLE_.__li|
00001a78  62 63 5f 63 73 75 5f 66  69 6e 69 00 5f 49 54 4d  |bc_csu_fini._ITM|
00001a88  5f 64 65 72 65 67 69 73  74 65 72 54 4d 43 6c 6f  |_deregisterTMClo|
00001a98  6e 65 54 61 62 6c 65 00  70 75 74 73 40 40 47 4c  |neTable.puts@@GL|
00001aa8  49 42 43 5f 32 2e 32 2e  35 00 5f 65 64 61 74 61  |IBC_2.2.5._edata|
00001ab8  00 5f 5f 6c 69 62 63 5f  73 74 61 72 74 5f 6d 61  |.__libc_start_ma|
00001ac8  69 6e 40 40 47 4c 49 42  43 5f 32 2e 32 2e 35 00  |in@@GLIBC_2.2.5.|
00001ad8  5f 5f 64 61 74 61 5f 73  74 61 72 74 00 5f 5f 67  |__data_start.__g|
00001ae8  6d 6f 6e 5f 73 74 61 72  74 5f 5f 00 5f 5f 64 73  |mon_start__.__ds|
00001af8  6f 5f 68 61 6e 64 6c 65  00 5f 49 4f 5f 73 74 64  |o_handle._IO_std|
00001b08  69 6e 5f 75 73 65 64 00  5f 5f 6c 69 62 63 5f 63  |in_used.__libc_c|
00001b18  73 75 5f 69 6e 69 74 00  5f 5f 62 73 73 5f 73 74  |su_init.__bss_st|
00001b28  61 72 74 00 6d 61 69 6e  00 66 6f 70 65 6e 40 40  |art.main.fopen@@|
00001b38  47 4c 49 42 43 5f 32 2e  32 2e 35 00 5f 4a 76 5f  |GLIBC_2.2.5._Jv_|
00001b48  52 65 67 69 73 74 65 72  43 6c 61 73 73 65 73 00  |RegisterClasses.|
00001b58  5f 5f 54 4d 43 5f 45 4e  44 5f 5f 00 5f 49 54 4d  |__TMC_END__._ITM|
00001b68  5f 72 65 67 69 73 74 65  72 54 4d 43 6c 6f 6e 65  |_registerTMClone|
00001b78  54 61 62 6c 65 00                                 |Table.|
00001b7e
```

### `Dynamic Section`

`定义`

当Elf64_Shdr::sh_type是SHT_DYNAMIC时,这个节头指向的节为Dynamic Section.

`作用`

保存动态链接信息.

`位置 尺寸 数量`

SHT_DYNAMIC类型的节头指出位置.

SHT_DYNAMIC类型的节头指出尺寸.

目前规定最多只能有一个.

`解释`

由Elf64_Dyn结构组成的数组.元素尺寸由Elf64_Shdr::e_shentsize指出.元素个数由为Elf64_Shdr::sh_size / Elf64_Shdr::sh_entsize.

`注意`

***

当 *Elf64_Shdr*::*sh_type* 是 SHT_DYNAMIC 时,这个节头指向的节为动态节.

动态节是 *Elf64_Dyn* 结构的序列.

> If an object file participates in dynamic linking, its program header table will have an element of type PT_DYNAMIC. This segment contains the .dynamic section. A special symbol, _DYNAMIC, labels the section, which contains an array of the following structures. See sys/link.h.

> The .dynamic section contains a series of structures that hold relevant dynamic linking information.The d_tag member controls the interpretation of d_un.

### `Symbol Table Section`

`定义`

当Elf64_Shdr::sh_type是SHT_SYMTAB|SHT_DYNSYM时,这个节头指向的节为Symbol Table Section.

Symbol Table Section是由Elf64_Sym结构组成的数组,这个数组被称为Symbol Table.

`作用`

保存着需要定位和重定位的symbolic definition和symbolic reference信息.

`位置 尺寸 数量`

SHT_SYMTAB|SHT_DYNSYM类型的节头指出位置.

SHT_SYMTAB|SHT_DYNSYM类型的节头指出尺寸.

目前规定最多只能有一个.

`解释`

由Elf64_Sym结构组成的数组.元素尺寸由Elf64_Shdr::e_shentsize指出.元素个数由为Elf64_Shdr::sh_size / Elf64_Shdr::sh_entsize.

Symbol Table索引0的符号Elf64_Sym的数据是固定的,st_shndx为SHN_UNDEF,其它全为0.代表一个未定义的符号索引.

Symbol Table元素的成员Elf64_Sym::st_name是索引值,String Table开始到符号名的偏移,给出符号名(字符串)在String Table of String Table Section中的位置;Elf64_Shdr::sh_link是一个索引值,在Section Header Table中的下标,间接给出了String Table.这样就可以找到符号名了.

`注意`

***

当 *Elf64_Shdr*::*sh_type* 是 SHT_SYMTAB | SHT_DYNSYM 时,这个节头指向的节为符号表节.

符号表节是Elf64_Sym结构的序列.

> An object file's symbol table holds information needed to locate and relocate a program's symbolic definitions and references.  A symbol table index is a subscript into this array.

### `Relocation Section`

`定义`

当Elf64_Shdr::sh_type是SHT_REL|SHT_RELA时,这个节头指向的节为Relocation Section.

Relocation is the process of connecting symbolic references with symbolic definitions.

`作用`

保存重定位信息.以便linker和loader去重定位.

`位置 尺寸 数量`

SHT_REL|SHT_RELA类型的节头指出位置.

SHT_REL|SHT_RELA类型的节头指出尺寸.

可以多个.

`解释`

由 Elf64_Rel/Elf64_Rela 结构组成的数组.元素尺寸由 Elf64_Shdr::e_shentsize 指出.元素个数由为 Elf64_Shdr::sh_size / Elf64_Shdr::sh_entsize.

Elf64_Rel/Elf64_Rela 指出引用的符号(Elf64_Sym),且能计算出要重定位的位置,并告知如何修复重定位.

- 引用的符号(Elf64_Sym):

  Relocation Table 元素的成员 Elf64_Rel/Elf64_Rela::r_info,可以计算出 ELF64_R_SYM ,是索引值,在 Symbol Table 中的下标.

  Elf64_Shdr::sh_link 是一个索引值,在 Section Header Table 中的下标,间接给出了 Symbol Table.

  这样就可以找到符号(Elf64_Sym)了.

- 要重定位的位置:

  Relocation Table 元素的成员 Elf64_Rel/Elf64_Rela::r_offset,是虚拟地址(利于 Shared Object and Executable Ojbect 执行重定位)或节偏移(被 Relocateable Object 使用,因为没有程序段,没有内存布局).

  Elf64_Shdr::sh_info 是一个索引值,在 Section Header Table 中的下标,间接给出了要重定位地址所在的节.

  这样就可以找到重定位地址了.

  - Relocateable Object:

    重定位地址 = Elf64_Rel/Elf64_Rela::r_offset + 重定位地址所在的节的首地址.

  - Shared Object and Executable Ojbect:

    重定位地址 = Elf64_Rel/Elf64_Rela::r_offset.

- 如何修复重定位:
    Relocation Table 元素的成员 Elf64_Rel/Elf64_Rela::r_info,可以计算出 ELF64_R_TYPE,这个值指出了如何修复.

`注意`

A relocation section can reference two other sections: a symbol table, identified by the sh_link section header entry, and a section to modify, identified by the sh_info section header entry. Sections specifies these relationships. A sh_info entry is required when a relocation section exists in a relocatable object, but is optional for executables and shared objects. The relocation offset is sufficient to perform the relocation.

***

关联节头类型是 SHT_REL | SHT_RELA 的节是重定位节,其内容是 *Elf64_Rel* | *Elf64_Rela* 结构数组.数组的元素大小与数量由关联节头给出.

> **Relocation** is the process of connecting symbolic references with symbolic definitions. For example, when a program calls a function, the associated call instruction must transfer control to the proper destination address at execution. Relocatable files must have information that describes how to modify their section contents. This information allows executable and shared object files to hold the right information for a process's program image. Relocation entries are these data.
>
> 重定位是连接符号引用与符号定义的过程.例如,当程序正在调用一个函数,相关的调用指令必须转移控制到适当的地址.重定位文件必须有描述怎样修改它们的节内容的信息.这些信息允许可执行的和共享对象文件,在进程的程序镜像中,去持有正确的信息.重定位条目是它们的数据.
>
> Rela entries contain an explicit addend. Entries of type Rel store an implicit addend in the location to be modified.
>
> rela条目包含一个显示的加数;rel条目在要被重定位的地址存储隐式加数.
>
> A relocation section can reference two other sections: a symbol table, identified by the sh_link section header entry, and a section to modify, identified by the sh_info section header entry. Sections specifies these relationships. A sh_info entry is required when a relocation section exists in a relocatable object, but is optional for executables and shared objects. The relocation offset is sufficient to perform the relocation.

找到重定位节:

``` {class=line-numbers}
$ readelf -S main
Section Headers:
  [Nr] Name              Type             Address           Offset
       Size              EntSize          Flags  Link  Info  Align
  [ 9] .rela.dyn         RELA             00000000004003a0  000003a0
       0000000000000018  0000000000000018   A       5     0     8
  [10] .rela.plt         RELA             00000000004003b8  000003b8
       0000000000000048  0000000000000018  AI       5    24     8
```

重定位节节头信息:

``` {class=line-numbers}
$ hexdump -C -s7952 -n64 ./main
00001f10  7a 00 00 00 04 00 00 00  02 00 00 00 00 00 00 00
00001f20  a0 03 40 00 00 00 00 00  a0 03 00 00 00 00 00 00
00001f30  18 00 00 00 00 00 00 00  05 00 00 00 00 00 00 00
00001f40  08 00 00 00 00 00 00 00  18 00 00 00 00 00 00 00

    sh_name      == 0x7a;
    sh_type      == 0x4;
    sh_flags     == 0x2;
    sh_addr      == 0x4003a0;
    sh_offset    == 0x3a0;
    sh_size      == 0x18;
    sh_link      == 0x5;
    sh_info      == 0x0;
    sh_addralign == 0x8;
    sh_entsize   == 0x18;

    sh_type      == 0x4; ==> SHT_RELA 4 This section holds Elf32_Rela array.
    sh_flags     == 0x2; ==> sh_flags & SHF_INFO_LINK != ture, so sh_info ...
    sh_link      == 0x5; ==> Section header index of the associated symbol table.
    sh_info      == 0x0; ==> Section header index of the section to which the relocation applies.

    Section header index of the associated symbol table: 0x5.
    Section header index of the section to which the relocation applies: 0x0.

$ hexdump -C -s8016 -n64 ./main
00001f50  84 00 00 00 04 00 00 00  42 00 00 00 00 00 00 00
00001f60  b8 03 40 00 00 00 00 00  b8 03 00 00 00 00 00 00
00001f70  48 00 00 00 00 00 00 00  05 00 00 00 18 00 00 00
00001f80  08 00 00 00 00 00 00 00  18 00 00 00 00 00 00 00

    sh_name      == 0x84;
    sh_type      == 0x4;
    sh_flags     == 0x42;
    sh_addr      == 0x4003b8;
    sh_offset    == 0x3b8;
    sh_size      == 0x48;
    sh_link      == 0x5;
    sh_info      == 0x18;
    sh_addralign == 0x8;
    sh_entsize   == 0x18;

    sh_type      == 0x4; ==> SHT_RELA 4 This section holds Elf32_Rela array.
    sh_flags     == 0x42; ==> sh_flags & SHF_INFO_LINK == ture, so sh_info ...
    sh_link      == 0x5; ==> Section header index of the associated symbol table.
    sh_info      == 0x18; ==> Section header index of the section to which the relocation applies.

    Section header index of the associated symbol table: 0x5.
    Section header index of the section to which the relocation applies: 0x18.
```

重定位条目信息:

``` {class=line-numbers}
$ hexdump -C -s0x3a0 -n24 ./main
000003a0  f8 0f 60 00 00 00 00 00  06 00 00 00 03 00 00 00
000003b0  00 00 00 00 00 00 00 00

r_offset    r_info        r_addend  ELF64_R_TYPE  ELF64_R_SYM
0x600ff8    0x300000006   0x0       0x6           0x3

$ hexdump -C -s0x3b8 -n72 ./main
000003b8  18 10 60 00 00 00 00 00  07 00 00 00 01 00 00 00
000003c8  00 00 00 00 00 00 00 00  20 10 60 00 00 00 00 00
000003d8  07 00 00 00 02 00 00 00  00 00 00 00 00 00 00 00
000003e8  28 10 60 00 00 00 00 00  07 00 00 00 04 00 00 00
000003f8  00 00 00 00 00 00 00 00

r_offset    r_info        r_addend  ELF64_R_TYPE  ELF64_R_SYM
0x601018    0x100000007   0x0       0x7           0x1
0x601020    0x200000007   0x0       0x7           0x2
0x601028    0x400000007   0x0       0x7           0x4
```

重定位条目名:

``` {class=line-numbers}
r_offset  r_info       r_addend  ELF64_R_TYPE  ELF64_R_SYM  Name
0x600ff8  0x300000006  0x0       0x6           0x3

ELF64_R_TYPE == 0x6  ==> S ==> Elf64_Sym::st_value 作为S.
Section header index of the associated symbol table: 0x5.
ELF64_R_SYM == 0x3 ==> symbol table index: 0x3;

Section header 5:
$ hexdump -C -s7696 -n64 ./main
00001e10  4e 00 00 00 0b 00 00 00  02 00 00 00 00 00 00 00
00001e20  b8 02 40 00 00 00 00 00  b8 02 00 00 00 00 00 00
00001e30  78 00 00 00 00 00 00 00  06 00 00 00 01 00 00 00
00001e40  08 00 00 00 00 00 00 00  18 00 00 00 00 00 00 00

sh_name      == 0x4e;
sh_type      == 0xb;
sh_flags     == 0x2;
sh_addr      == 0x4002b8;
sh_offset    == 0x2b8;
sh_size      == 0x78;
sh_link      == 0x6; ==> Section header index of the associated string table: 0x6.
sh_info      == 0x1;
sh_addralign == 0x8;
sh_entsize   == 0x18;

0x2b8 + 3 * 0x18 = 0x300

symbol table index 3:
$ hexdump -C -s0x300 -n24 ./main
00000300  28 00 00 00 20 00 00 00  00 00 00 00 00 00 00 00
00000310  00 00 00 00 00 00 00 00

st_name  == 0x28; ==> symbol string table index: 0x28.
st_info  == 0x20;
st_other == 0x0;
st_shndx == 0x0; ==> section header table index: 0x0;
st_value == 0x0;
st_size  == 0x0;

Section header index of the associated string table: 0x6.
symbol string table index: 0x28.

Section header 6:
$ hexdump -C -s7760 -n64 ./main
00001e50  56 00 00 00 03 00 00 00  02 00 00 00 00 00 00 00
00001e60  30 03 40 00 00 00 00 00  30 03 00 00 00 00 00 00
00001e70  43 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00
00001e80  01 00 00 00 00 00 00 00  00 00 00 00 00 00 00 00

sh_name      == 0x56;
sh_type      == 0x3;
sh_flags     == 0x2;
sh_addr      == 0x400330;
sh_offset    == 0x330;
sh_size      == 0x43;
sh_link      == 0x0;
sh_info      == 0x0;
sh_addralign == 0x1;
sh_entsize   == 0x0;

Section 6 ==> 0x28:
$ hexdump -C -s0x358 -n16 ./main
00000358  5f 5f 67 6d 6f 6e 5f 73  74 61 72 74 5f 5f 00 47  __gmon_start__.G

final:
r_offset  r_info       r_addend  ELF64_R_TYPE  ELF64_R_SYM  Name
0x600ff8  0x300000006  0x0       0x6           0x3          __gmon_start__
```

类似的方法得到重定位条目名:

``` {class=line-numbers}
r_offset  r_info       r_addend  ELF64_R_TYPE  ELF64_R_SYM  Name
0x601018  0x100000007  0x0       0x7           0x1          puts@GLIBC_2.2.5
0x601020  0x200000007  0x0       0x7           0x2          __libc_start_main@GLIBC_2.2.5
0x601028  0x400000007  0x0       0x7           0x4          fopen@GLIBC_2.2.5
```

重定位条目重定位跟踪:

``` {class=line-numbers}
$ hexdump -C -s8016 -n64 ./main
00001f50  84 00 00 00 04 00 00 00  42 00 00 00 00 00 00 00
00001f60  b8 03 40 00 00 00 00 00  b8 03 00 00 00 00 00 00
00001f70  48 00 00 00 00 00 00 00  05 00 00 00 18 00 00 00
00001f80  08 00 00 00 00 00 00 00  18 00 00 00 00 00 00 00

    sh_name      == 0x84;
    sh_type      == 0x4;
    sh_flags     == 0x42;
    sh_addr      == 0x4003b8;
    sh_offset    == 0x3b8;
    sh_size      == 0x48;
    sh_link      == 0x5;
    sh_info      == 0x18;
    sh_addralign == 0x8;
    sh_entsize   == 0x18;

    sh_type      == 0x4; ==> SHT_RELA 4 This section holds Elf32_Rela array.
    sh_flags     == 0x42; ==> sh_flags & SHF_INFO_LINK == ture, so sh_info ...
    sh_link      == 0x5; ==> Section header index of the associated symbol table.
    sh_info      == 0x18; ==> Section header index of the section to which the relocation applies.

    Section header index of the associated symbol table: 0x5.
    Section header index of the section to which the relocation applies: 0x18.
```

找到关联的节头索引,这里取 puts & fopen :

``` {class=line-numbers}
重定位节:
$ readelf -S main
Section Headers:
  [Nr] Name              Type             Address           Offset
       Size              EntSize          Flags  Link  Info  Align
  [10] .rela.plt         RELA             00000000004003b8  000003b8
       0000000000000048  0000000000000018  AI       5    24     8

得到索引10重定位节节头信息:
$ hexdump -C -s8016 -n64 ./main
00001f50  84 00 00 00 04 00 00 00  42 00 00 00 00 00 00 00
00001f60  b8 03 40 00 00 00 00 00  b8 03 00 00 00 00 00 00
00001f70  48 00 00 00 00 00 00 00  05 00 00 00 18 00 00 00
00001f80  08 00 00 00 00 00 00 00  18 00 00 00 00 00 00 00

    sh_name      == 0x84;
    sh_type      == 0x4;
    sh_flags     == 0x42;
    sh_addr      == 0x4003b8;
    sh_offset    == 0x3b8;
    sh_size      == 0x48;
    sh_link      == 0x5;
    sh_info      == 0x18;
    sh_addralign == 0x8;
    sh_entsize   == 0x18;

    sh_type      == 0x4; ==> SHT_RELA 4 This section holds Elf32_Rela array.
    sh_flags     == 0x42; ==> sh_flags & SHF_INFO_LINK == ture, so sh_info ...
    sh_link      == 0x5; ==> Section header index of the associated symbol table.
    sh_info      == 0x18; ==> Section header index of the section to which the relocation applies.

    Section header index of the associated symbol table: 0x5.
    Section header index of the section to which the relocation applies: 0x18.

得到重定位条目信息:
$ hexdump -C -s0x3b8 -n72 ./main
000003b8  18 10 60 00 00 00 00 00  07 00 00 00 01 00 00 00
000003c8  00 00 00 00 00 00 00 00  20 10 60 00 00 00 00 00
000003d8  07 00 00 00 02 00 00 00  00 00 00 00 00 00 00 00
000003e8  28 10 60 00 00 00 00 00  07 00 00 00 04 00 00 00
000003f8  00 00 00 00 00 00 00 00

r_offset    r_info        r_addend  ELF64_R_TYPE  ELF64_R_SYM
0x601018    0x100000007   0x0       0x7           0x1
0x601020    0x200000007   0x0       0x7           0x2
0x601028    0x400000007   0x0       0x7           0x4

去掉不想要的,上面名字分析了:
r_offset  r_info       r_addend  ELF64_R_TYPE  ELF64_R_SYM  Name
0x601018  0x100000007  0x0       0x7           0x1          puts@GLIBC_2.2.5
0x601028  0x400000007  0x0       0x7           0x4          fopen@GLIBC_2.2.5

得到对应的Elf64_Sym条目:
ELF64_R_SYM ==> symbol table index: 0x1.
sh_type == 4 ==> index in section header table of symbol table: sh_link == 0x5.

    Section header 5:
    $ hexdump -C -s7696 -n64 ./main
    00001e10  4e 00 00 00 0b 00 00 00  02 00 00 00 00 00 00 00
    00001e20  b8 02 40 00 00 00 00 00  b8 02 00 00 00 00 00 00
    00001e30  78 00 00 00 00 00 00 00  06 00 00 00 01 00 00 00
    00001e40  08 00 00 00 00 00 00 00  18 00 00 00 00 00 00 00

    sh_name      == 0x4e;
    sh_type      == 0xb;
    sh_flags     == 0x2;
    sh_addr      == 0x4002b8;
    sh_offset    == 0x2b8;
    sh_size      == 0x78;
    sh_link      == 0x6; ==> Section header index of the associated string table: 0x6.
    sh_info      == 0x1;
    sh_addralign == 0x8;
    sh_entsize   == 0x18;

    0x2b8 + 1 * 0x18 = 0x2d0

    symbol table index 1:
    $ hexdump -C -s0x2d0 -n24 ./main
    000002d0  11 00 00 00 12 00 00 00  00 00 00 00 00 00 00 00
    000002e0  00 00 00 00 00 00 00 00

st_name  == 0x11;
st_info  == 0x12;
st_other == 0x0;
st_shndx == 0x0;
st_value == 0x0;
st_size  == 0x0;

因为ELF64_R_TYPE==7,lazy bind, 所以Elf32_Addr::r_offset给出了plt表条目,
```

puts:

``` {class=line-numbers}
r_offset  r_info       r_addend  ELF64_R_TYPE  ELF64_R_SYM  Name
0x601018  0x100000007  0x0       0x7           0x1          puts@GLIBC_2.2.5
```

fopen:

``` {class=line-numbers}
r_offset  r_info       r_addend  ELF64_R_TYPE  ELF64_R_SYM  Name
0x601028  0x400000007  0x0       0x7           0x4          fopen@GLIBC_2.2.5
```

***

``` {class=line-numbers}
[~/Desktop/untitled folder]$ readelf -s ./main

Symbol table '.dynsym' contains 5 entries:
   Num:    Value          Size Type    Bind   Vis      Ndx Name
     0: 0000000000000000     0 NOTYPE  LOCAL  DEFAULT  UND
     1: 0000000000000000     0 FUNC    GLOBAL DEFAULT  UND puts@GLIBC_2.2.5 (2)
     2: 0000000000000000     0 FUNC    GLOBAL DEFAULT  UND __libc_start_main@GLIBC_2.2.5 (2)
     3: 0000000000000000     0 NOTYPE  WEAK   DEFAULT  UND __gmon_start__
     4: 0000000000000000     0 FUNC    GLOBAL DEFAULT  UND fopen@GLIBC_2.2.5 (2)

Symbol table '.symtab' contains 73 entries:
   Num:    Value          Size Type    Bind   Vis      Ndx Name
     0: 0000000000000000     0 NOTYPE  LOCAL  DEFAULT  UND
     1: 0000000000400238     0 SECTION LOCAL  DEFAULT    1
     2: 0000000000400254     0 SECTION LOCAL  DEFAULT    2
     3: 0000000000400274     0 SECTION LOCAL  DEFAULT    3
     4: 0000000000400298     0 SECTION LOCAL  DEFAULT    4
```

``` {class=line-numbers}
000003a0  f8 0f 60 00 00 00 00 00  06 00 00 00 03 00 00 00
000003b0  00 00 00 00 00 00 00 00

r_offset      0x600ff8
r_info        0x300000006
r_addend      0x0
ELF64_R_TYPE  0x6         R_AMD64_GLOB_DAT  S
ELF64_R_SYM   0x3         inedex 3

inedex 3 ==>
R_AMD64_GLOB_DAT  S ==>
```

``` {class=line-numbers}
000003b8  18 10 60 00 00 00 00 00  07 00 00 00 01 00 00 00
000003c8  00 00 00 00 00 00 00 00

r_offset      0x601018
r_info        0x100000007
r_addend      0x0
ELF64_R_TYPE  0x7         R_AMD64_JUMP_SLOT   S
ELF64_R_SYM   0x1         inedex 1
```

``` {class=line-numbers}
000003c8                           20 10 60 00 00 00 00 00
000003d8  07 00 00 00 02 00 00 00  00 00 00 00 00 00 00 00

r_offset      0x601020
r_info        0x200000007
r_addend      0x0
ELF64_R_TYPE  0x7         R_AMD64_JUMP_SLOT   S
ELF64_R_SYM   0x2         inedex 2
```

``` {class=line-numbers}
000003e8  28 10 60 00 00 00 00 00  07 00 00 00 04 00 00 00
000003f8  00 00 00 00 00 00 00 00

r_offset      0x601028
r_info        0x400000007
r_addend      0x0
ELF64_R_TYPE  0x7         R_AMD64_JUMP_SLOT   S
ELF64_R_SYM   0x4         inedex 4
```

``` {class=line-numbers}
$ readelf -r ./main

Relocation section '.rela.dyn' at offset 0x3a0 contains 1 entries:
  Offset          Info           Type           Sym. Value    Sym. Name + Addend
000000600ff8  000300000006 R_X86_64_GLOB_DAT 0000000000000000 __gmon_start__ + 0

Relocation section '.rela.plt' at offset 0x3b8 contains 3 entries:
  Offset          Info           Type           Sym. Value    Sym. Name + Addend
000000601018  000100000007 R_X86_64_JUMP_SLO 0000000000000000 puts@GLIBC_2.2.5 + 0
000000601020  000200000007 R_X86_64_JUMP_SLO 0000000000000000 __libc_start_main@GLIBC_2.2.5 + 0
000000601028  000400000007 R_X86_64_JUMP_SLO 0000000000000000 fopen@GLIBC_2.2.5 + 0

```

### `Symbol Sort Sections`

# `Type Collection`

## `Elf64_Ehdr`

``` {class=line-numbers}
#define EI_NIDENT       16

typedef struct {
  unsigned char  e_ident[EI_NIDENT];
  Elf32_Half     e_type;
  Elf32_Half     e_machine;
  Elf32_Word     e_version;
  Elf32_Addr     e_entry;
  Elf32_Off      e_phoff;
  Elf32_Off      e_shoff;
  Elf32_Word     e_flags;
  Elf32_Half     e_ehsize;
  Elf32_Half     e_phentsize;
  Elf32_Half     e_phnum;
  Elf32_Half     e_shentsize;
  Elf32_Half     e_shnum;
  Elf32_Half     e_shstrndx;
} Elf32_Ehdr;

typedef struct {
  unsigned char  e_ident[EI_NIDENT];
  Elf64_Half     e_type;
  Elf64_Half     e_machine;
  Elf64_Word     e_version;
  Elf64_Addr     e_entry;
  Elf64_Off      e_phoff;
  Elf64_Off      e_shoff;
  Elf64_Word     e_flags;
  Elf64_Half     e_ehsize;
  Elf64_Half     e_phentsize;
  Elf64_Half     e_phnum;
  Elf64_Half     e_shentsize;
  Elf64_Half     e_shnum;
  Elf64_Half     e_shstrndx;
} Elf64_Ehdr;
```

`e_ident`

The initial bytes mark the file as an object file. These bytes provide machine-independent data with which to decode and interpret the file's contents. Complete descriptions appear in Elf64_Ehdr::e_ident.

`e_type`

Identifies the object file type, as listed in the following table.

| Name | Value | Meaning | example |
|---|---|---|---|
| ET_NONE   | 0      | No file type |
| ET_REL    | 1      | Relocatable file | gcc -c -o main.o main.c
| ET_EXEC   | 2      | Executable file | gcc -o main main.o
| ET_DYN    | 3      | Shared object file | gcc -shared -fPIC -o main.so main.c
| ET_CORE   | 4      | Core file | ar -rc main.a main.o
| ET_LOPROC | 0xff00 | Processor-specific |
| ET_HIPROC | 0xffff | Processor-specific |

Although the core file contents are unspecified, type ET_CORE is reserved to mark the file. Values from ET_LOPROC through ET_HIPROC (inclusive) are reserved for processor-specific semantics. Other values are reserved for future use.

`e_machine`

Specifies the required architecture for an individual file. Relevant architectures are listed in the following table.

| Name      | Value  | Meaning
| --- | ---| ---
| EM_NONE        | 0  | No machine
| EM_SPARC       | 2  | SPARC
| EM_386         | 3  | Intel 80386
| EM_SPARC32PLUS | 18 | Sun SPARC 32+
| EM_SPARCV9     | 43 | SPARC V9
| EM_AMD64       | 62 | AMD 64

Other values are reserved for future use. Processor-specific ELF names are distinguished by using the machine name. For example, the flags defined for e_flags use the prefix EF_. A flag that is named WIDGET for the EM_XYZ machine would be called EF_XYZ_WIDGET.

`e_version`

Identifies the object file version, as listed in the following table.

| Name | Value  | Meaning |
|---|---|---|
EV_NONE    | 0   | Invalid version |
EV_CURRENT | >=1 | Current version |

The value 1 signifies the original file format. The value of EV_CURRENT changes as necessary to reflect the current version number.

`e_entry`

The virtual address to which the system first transfers control, thus starting the process. If the file has no associated entry point, this member holds zero.

`e_phoff`

The program header table's file offset in bytes. If the file has no program header table, this member holds zero.

`e_shoff`

The section header table's file offset in bytes. If the file has no section header table, this member holds zero.

`e_flags`

Processor-specific flags associated with the file. Flag names take the form EF_machine_flag. This member is presently zero for x86. The SPARC flags are listed in the following table.

| Name | Value  | Meaning |
|---|---|---|
EF_SPARCV9_TSO    | 0x0      | Total Store Ordering
EF_SPARCV9_PSO    | 0x1      | Partial Store Ordering
EF_SPARCV9_RMO    | 0x2      | Relaxed Memory Ordering
EF_SPARCV9_MM     | 0x3      | Mask for Memory Model
EF_SPARC_32PLUS   | 0x000100 | Generic V8+ features
EF_SPARC_SUN_US1  | 0x000200 | Sun UltraSPARC 1 Extensions
EF_SPARC_HAL_R1   | 0x000400 | HAL R1 Extensions
EF_SPARC_SUN_US3  | 0x000800 | Sun UltraSPARC 3 Extensions
EF_SPARC_EXT_MASK | 0xffff00 | Vendor Extension mask

`e_ehsize`

The ELF header's size in bytes.

`e_phentsize`

The size in bytes of one entry in the file's program header table. All entries are the same size.

`e_phnum`

The number of entries in the program header table. The product of e_phentsize and e_phnum gives the table's size in bytes. If a file has no program header table, e_phnum holds the value zero.

If the number of program headers is greater than or equal to PN_XNUM (0xffff), this member has the value PN_XNUM (0xffff). The actual number of program header table entries is contained in the sh_info field of the section header at index 0. Otherwise, the sh_info member of the initial section header entry contains the value zero. See Table 12-6 and Table 12-7.

`e_shentsize`

A section header's size in bytes. A section header is one entry in the section header table. All entries are the same size.

`e_shnum`

The number of entries in the section header table. The product of e_shentsize and e_shnum gives the section header table's size in bytes. If a file has no section header table, e_shnum holds the value zero.

If the number of sections is greater than or equal to SHN_LORESERVE (0xff00), e_shnum has the value zero. The actual number of section header table entries is contained in the sh_size field of the section header. Otherwise, the sh_size member of the initial section header entry contains the value zero.

`e_shstrndx`

The section header table index of the entry that is associated with the section name string table. If the file has no section name string table, this member holds the value SHN_UNDEF.

If the section name string table section index is greater than or equal to SHN_LORESERVE (0xff00), this member has the value SHN_XINDEX (0xffff) and the actual index of the section name string table section is contained in the sh_link field of the section header at index 0. Otherwise, the sh_link member of the initial section header entry contains the value zero.

## `Elf64_Phdr`

``` {class=line-numbers}
typedef struct {
        Elf32_Word      p_type;
        Elf32_Off       p_offset;
        Elf32_Addr      p_vaddr;
        Elf32_Addr      p_paddr;
        Elf32_Word      p_filesz;
        Elf32_Word      p_memsz;
        Elf32_Word      p_flags;
        Elf32_Word      p_align;
} Elf32_Phdr;

typedef struct {
        Elf64_Word      p_type;
        Elf64_Word      p_flags;
        Elf64_Off       p_offset;
        Elf64_Addr      p_vaddr;
        Elf64_Addr      p_paddr;
        Elf64_Xword     p_filesz;
        Elf64_Xword     p_memsz;
        Elf64_Xword     p_align;
} Elf64_Phdr;
```

`p_type`

`p_flags`

`p_offset`

`p_vaddr`

`p_paddr`

`p_filesz`

`p_memsz`

`p_align`


## `Elf64_Shdr`

``` {class=line-numbers}
typedef struct {
  elf32_Word  sh_name;
  Elf32_Word  sh_type;
  Elf32_Word  sh_flags;
  Elf32_Addr  sh_addr;
  Elf32_Off   sh_offset;
  Elf32_Word  sh_size;
  Elf32_Word  sh_link;
  Elf32_Word  sh_info;
  Elf32_Word  sh_addralign;
  Elf32_Word  sh_entsize;
} Elf32_Shdr;

typedef struct {
  Elf64_Word   sh_name;
  Elf64_Word   sh_type;
  Elf64_Xword  sh_flags;
  Elf64_Addr   sh_addr;
  Elf64_Off    sh_offset;
  Elf64_Xword  sh_size;
  Elf64_Word   sh_link;
  Elf64_Word   sh_info;
  Elf64_Xword  sh_addralign;
  Elf64_Xword  sh_entsize;
} Elf64_Shdr;
```

`sh_name`

> The name of the section. This members value is an index into the section header string table section giving the location of a null-terminated string. Section names and their descriptions are listed in [Elf64_Shdr::sh_name](#elf64_shdrsh_name).

偏移值,间接指出节的名称.这个值是相对于字符串表节的一个偏移,定位到的位置是一个以null结束的字符串,也就是节的名称.

`sh_type`

> Categorizes the section's contents and semantics. Section types and their descriptions are listed in <a href="#tc2-section-type-elf64_shdrsh_type"> Tables Collection tc.2</a>.

对节的内容和语义分类.

`sh_flags`

> Sections support 1-bit flags that describe miscellaneous attributes. Flag definitions are listed in
<a href="#tc3-section-flag-elf64_shdrsh_flags"> Tables Collection tc.3</a>.

支持1-bit标志去描述一些属性.

`sh_addr`

> If the section appears in the memory image of a process, this member gives the address at which the section's first byte should reside. Otherwise, the member contains the value zero.

如果节出在进程的内存镜像中,这个值给出了节的第一字节应该出现的位置;否则,为零.

`sh_offset`

> The byte offset from the beginning of the file to the first byte in the section. For a SHT_NOBITS section, this member indicates the conceptual offset in the file, as the section occupies no space in the file.

一个偏移,从文件开始到节的开始.对于*sh_type*=SHT_NOBITS类型的节,这个值表明在文件中概念的偏移,因为该节在文件中不占用空间.

`sh_size`

> The section's size in bytes. Unless the section type is SHT_NOBITS, the section occupies sh_size bytes in the file. A section of type SHT_NOBITS can have a nonzero size, but the section occupies no space in the file.

节的字节尺寸.

`sh_link`

> A section header table index link, interpretation depends on the section type. Details see <a href="#tc4-section-link-elf64_shdrsh_link"> Tables Collection tc.4</a>.

一个节头表索引链接,其解释依赖于*sh_type*.

`sh_info`

> Extra information, interpretation depends on the section type.  If the sh_flags field for this section header includes the attribute SHF_INFO_LINK, then this member represents a section header table index. Details See <a href="#tc5-section-info-elf64_shdrsh_info"> Tables Collection tc.5</a>.

额外信息,其解释依赖于*sh_type*.如果*sh_flags*包含SHF_INFO_LINK,其代表一个节头表索引.如,当重定位条目Elf64_Rela::r_offset给出偏移时,会用这个成员指出修复地址在哪个节中,这样就可以定位到修复地址了.

`sh_addralign`

> Some sections have address alignment constraints. For example, if a section holds a double-word, the system must ensure double-word alignment for the entire section. In this case, the value of sh_addr must be congruent to 0, modulo the value of sh_addralign. Currently, only 0 and positive integral powers of two are allowed. Values 0 and 1 mean the section has no alignment constraints.

`sh_entsize`

> Some sections hold a table of fixed-size entries, such as a symbol table. For such a section, this member gives the size in bytes of each entry. The member contains the value zero if the section does not hold a table of fixed-size entries.

一些节是一张表,表保存一定数量的固定尺寸的条目.对于这样的节,这个成员给出了条目的尺寸;如果不是这样的节,为零.

## `Elf64_Dyn`

``` {class=line-numbers}
typedef struct
{
  Elf32_Sword    d_tag;
  union
  {
    Elf32_Word d_val;
    Elf32_Addr d_ptr;
  } d_un;
} Elf32_Dyn;
extern Elf32_Dyn _DYNAMIC[];

typedef struct
{
  Elf64_Sxword    d_tag;
  union
  {
    Elf64_Xword d_val;
    Elf64_Addr  d_ptr;
  } d_un;
} Elf64_Dyn;
extern Elf64_Dyn _DYNAMIC[];
```

`d_tag`

*d_tag* controls the interpretation of *d_un*. See *Elf64_Dyn::d_tag*.

`d_un`

- d_val
    These objects represent integer values with various interpretations.

- d_ptr
    These objects represent program virtual addresses. A file's virtual addresses might not match the memory virtual addresses during execution. When interpreting addresses contained in the dynamic structure, the runtime linker computes actual addresses, based on the original file value and the memory base address. For consistency, files do not contain relocation entries to correct addresses in the dynamic structure.

- d_off

## `Elf64_Sym`

``` {class=line-numbers}
typedef struct {
  Elf32_Word      st_name;
  Elf32_Addr      st_value;
  Elf32_Word      st_size;
  unsigned char   st_info;
  unsigned char   st_other;
  Elf32_Half      st_shndx;
} Elf32_Sym;

typedef struct {
  Elf64_Word      st_name;
  unsigned char   st_info;
  unsigned char   st_other;
  Elf64_Half      st_shndx;
  Elf64_Addr      st_value;
  Elf64_Xword     st_size;
} Elf64_Sym;
```

`st_name`

An index into the object file's symbol string table, which holds the character representations of the symbol names. If the value is nonzero, the value represents a string table index that gives the symbol name. Otherwise, the symbol table entry has no name.

`st_info`

The symbol's type *ELF64_ST_TYPE* and binding attributes *ELF64_ST_BIND*.

``` {class=line-numbers}
#define ELF32_ST_BIND(info)          ((info) >> 4)
#define ELF32_ST_TYPE(info)          ((info) & 0xf)
#define ELF32_ST_INFO(bind, type)    (((bind)<<4)+((type)&0xf))

#define ELF64_ST_BIND(info)          ((info) >> 4)
#define ELF64_ST_TYPE(info)          ((info) & 0xf)
#define ELF64_ST_INFO(bind, type)    (((bind)<<4)+((type)&0xf))
```

`st_other`

A symbol's visibility. See *ELF64_ST_VISIBILITY*. If be zero, and have no defined meaning. The following code shows how to manipulate the values for both 32–bit objects and 64–bit objects:

``` {class=line-numbers}
#define ELF32_ST_VISIBILITY(o)       ((o)&0x3)
#define ELF64_ST_VISIBILITY(o)       ((o)&0x3)
```

`st_shndx`

Every symbol table entry is defined in relation to some section. This member holds the relevant section header table index. Some section indexes indicate special meanings. See Table 12-4.

If this member contains SHN_XINDEX, then the actual section header index is too large to fit in this field. The actual value is contained in the associated section of type SHT_SYMTAB_SHNDX.

1. If the *Elf64_Sym*::*st_shndx* is not SHN_UNDEF , the dynamic linker has found a definition for the symbol, and uses its *Elf64_Sym*::*st_value* as the symbol's address.

2. If the *Elf64_Sym*::*st_shndx* is SHN_UNDEF and the *ELF64_ST_TYPE* is of type STT_FUNC and the *Elf64_Sym*::*st_value* is not zero, the dynamic linker recognizes this entry as special and uses *Elf64_Sym*::*st_value* as the symbol's address.

3. Otherwise, the dynamic linker considers the symbol to be undefined within the executable file and continues processing.

`st_value`

The value of the associated symbol. The value can be an absolute value or an address, depending on the context. See Symbol Values.

*st_value* have slightly different interpretations for different object file types:

- In relocatable files, *st_value* holds alignment constraints for a symbol when section index is SHN_COMMON.

- In relocatable files, *st_value* holds a section offset for a defined symbol. *st_value* is an offset from the beginning of the section that *st_shndx* identifies.

- In executable and shared object files, *st_value* holds a virtual address. To make these files' symbols more useful for the runtime linker, the section offset (file interpretation) gives way to a virtual address (memory interpretation) for which the section number is irrelevant.

Although the symbol table values have similar meanings for different object files, the data allow efficient access by the appropriate programs.

`st_size`

Many symbols have associated sizes. For example, a data object's size is the number of bytes that are contained in the object. This member holds the value zero if the symbol has no size or an unknown size.

## `Elf64_Rel`

``` {class=line-numbers}
typedef struct {
  Elf32_Addr      r_offset;
  Elf32_Word      r_info;
} Elf32_Rel;

typedef struct {
  Elf64_Addr      r_offset;
  Elf64_Xword     r_info;
} Elf64_Rel;
```

Details to see Elf64_Rela.

## `Elf64_Rela`

``` {class=line-numbers}
typedef struct {
  Elf32_Addr      r_offset;
  Elf32_Word      r_info;
  Elf32_Sword     r_addend;
} Elf32_Rela;

typedef struct {
  Elf64_Addr      r_offset;
  Elf64_Xword     r_info;
  Elf64_Sxword    r_addend;
} Elf64_Rela;
```

Rela entries contain an explicit addend. Entries of type Rel store an implicit addend in the location to be modified. 32–bit SPARC use only Elf32_Rela relocation enteries. 64–bit SPARC and 64–bit x86 use only Elf64_Rela relocation entries. Thus, the r_addend member serves as the relocation addend. x86 uses only Elf32_Rel relocation entries. The field to be relocated holds the addend. In all cases, the addend and the computed result use the same byte order.

A relocation section can reference two other sections: a symbol table, identified by the sh_link section header entry, and a section to modify, identified by the sh_info section header entry. Sections specifies these relationships. A sh_info entry is required when a relocation section exists in a relocatable object, but is optional for executables and shared objects. The relocation offset is sufficient to perform the relocation.

`r_offset`

一个值,虚拟地址或偏移.对于一个重定位文件,这个值表示节偏移(哪个节);对于可执行的或共享的对象,值是受重定位影响的储存单元的虚拟地址,运行时链接器使用虚拟地址是更有利的.对于这个值的使用,是由重定位类型ELF64_R_TYPE说明的.

如果是偏移,怎么找这个节?
Elf64_Shdr::sh_info给出了答案,它指定了重定位地址所在的节的节头,在节头表中的索引.这样就能定位到一个绝对的地址了.



This member gives the location at which to apply the relocation action. Different object files have slightly different interpretations for this member.

这个成员给出了应用重定位动作的位置.不同的对象文件有轻微的不同解释.

For a relocatable file, the value indicates a section offset. The relocation section describes how to modify another section in the file. Relocation offsets designate a storage unit within the second section.

对于一个重定位文件,这个值表示节偏移.这个重定位节描述怎样修改文件中的另一个节.重定位偏移指出一个在第二个节中的存储单元.

For an executable or shared object, the value indicates the virtual address of the storage unit affected by the relocation. This information makes the relocation entries more useful for the runtime linker.

对于一个可执行的或共享的对象,这个值指出受重定位影响的储存单元的虚拟地址.此信息使重定位条目对于运行时链接器更有用.

Although the interpretation of the member changes for different object files to allow efficient access by the relevant programs, the meanings of the relocation types stay the same.

尽管,对于不同的对象文件,成员的解释有变动,以允许相关程序有效地访问,但重新定位类型的含义保持相同.

In all cases, the r_offset value designates the offset or virtual address of the first byte of the affected storage unit. The relocation type specifies which bits to change and how to calculate their values.

所有情况下,这个成员指明虚拟地址的偏移,受影响的储存单元的的第一个字节.重定位类型指出哪些字节改变,和怎样计算它们的值.

`r_info`

这个成员给出了二类信息:

- 重定位类型ELF64_R_TYPE

    指出如何计算要修复的位置.详细见ELF64_R_TYPE.

- Symbol Table索引ELF64_R_SYM.

    指出符号在符号表中的索引.

    那么是哪个符号表呢?
    Elf64_Shdr::sh_link给出了答案,它指定了符号表所在的节的节头,在节头表中的索引.这样就能从Elf64_Rela定位到Elf64_Sym了.

    如果索引是STN_UNDEF,表示未定义的符号索引,修复时,把Elf64_Rela::r_offset当0使用.



This member gives both the symbol table index, with respect to which the relocation must be made, and the type of relocation to apply. For example, a call instruction's relocation entry holds the symbol table index of the function being called. If the index is STN_UNDEF, the undefined symbol index, the relocation uses zero as the symbol value.

这个成员给出了必需被重定位的符号表索引 *ELF64_R_SYM* 和应用的重定位类型 *ELF64_R_TYPE*.例如,一个调用指令重定位条目持有将被调用的函数的符号表索引.如果索引是STN_UNDEF,未定义的符号索引,这个重定位使用0作为符号值.

Relocation types are processor-specific. A relocation entry's relocation type or symbol table index is the result of applying *ELF64_R_TYPE* or *ELF64_R_SYM*, respectively, to the entry's r_info member.

重定位类型是处理器指定的,重定位条目的类型或索引是应用于 ELF64_R_TYPE 或 ELF64_R_SYM 到该成员的结果,各自地.

``` {class=line-numbers}
#define ELF64_R_SYM(info)             ((info)>>8)
#define ELF64_R_TYPE(info)            ((unsigned char)(info))
#define ELF32_R_INFO(sym, type)       (((sym)<<8)+(unsigned char)(type))

#define ELF64_R_SYM(info)             ((info)>>32)
#define ELF64_R_TYPE(info)            ((Elf64_Word)(info))
#define ELF64_R_INFO(sym, type)       (((Elf64_Xword)(sym)<<32)+ \
                                        (Elf64_Xword)(type))
```

`r_addend`

这个成员提供了一个常量加数r_addend,被用途计算重定位地址填充值.

Elf64_Rela类型有显示的常量加数Elf64_Rela::r_addend;Elf64_Rel类型有隐式的常量加数,要重定位的地址的内容就是了.

This member specifies a constant addend used to compute the value to be stored into the relocatable field.

# `Table Collection`

## `ELF Identification Index`

| Name | Value | Purpose |
| --- | ---| --- |
| EI_MAG0       | 0  | File identification |
| EI_MAG1       | 1  | File identification |
| EI_MAG2       | 2  | File identification |
| EI_MAG3       | 3  | File identification |
| EI_CLASS      | 4  | File class |
| EI_DATA       | 5  | Data encoding |
| EI_VERSION    | 6  | File version |
| EI_OSABI      | 7  | Operating system/ABI identification |
| EI_ABIVERSION | 8  | ABI version |
| EI_PAD        | 9  | Start of padding bytes |
| EI_NIDENT     | 16 | Size of e_ident |

`EI_MAG0 ~ EI_MAG3:`

A 4–byte magic number, identifying the file as an ELF object file, as listed in
the following table.

| Name    | Value | Position
| --- | ---| ---
| ELFMAG0 | 0x7f  | e_ident[EI_MAG0]
| ELFMAG1 | 'E'   | e_ident[EI_MAG1]
| ELFMAG2 | 'L'   | e_ident[EI_MAG2]
| ELFMAG3 | 'F'   | e_ident[EI_MAG3]

`EI_CLASS:`

Byte e_ident[EI_CLASS] identifies the file's class, or capacity, as listed in
the following table.

| Name | Value | Meaning
|  --- | ---| ---
| ELFCLASSNONE | 0 | Invalid class
| ELFCLASS32   | 1 | 32–bit objects
| ELFCLASS64   | 2 | 64–bit objects

`EI_DATA:`

Byte e_ident[EI_DATA] specifies the data encoding of the processor-specific data
in the object file, as listed in the following table.

| Name | Value | Meaning
|  --- | ---| ---
| ELFDATANONE | 0 | Invalid data encoding
| ELFDATA2LSB | 1 | little endian
| ELFDATA2MSB | 2 | big endian

`EI_VERSION:`

Byte e_ident[EI_VERSION] specifies the ELF header version number. Currently,
this value must be EV_CURRENT.

`EI_OSABI:`

Byte e_ident[EI_OSABI] identifies the operating system together with the ABI to
which the object is targeted. Some fields in other ELF structures have flags
and values that have operating system or ABI specific meanings. The
interpretation of those fields is determined by the value of this byte.

| Name | Value | Meaning
|  --- | ---| ---
| ELFOSABI_NONE       | 0   | UNIX System V ABI.
| ELFOSABI_SYSV       | 0   | Alias.
| ELFOSABI_HPUX       | 1   | HP-UX.
| ELFOSABI_NETBSD     | 2   | NetBSD.
| ELFOSABI_GNU        | 3   | Object uses GNU ELF extensions.
| ELFOSABI_LINUX      | 3   | Compatibility alias.
| ELFOSABI_SOLARIS    | 6   | Sun Solaris.
| ELFOSABI_AIX        | 7   | IBM AIX.
| EI_OSABI            | 7   | OS ABI identification
| ELFOSABI_IRIX       | 8   | SGI Irix.
| ELFOSABI_FREEBSD    | 9   | FreeBSD.
| ELFOSABI_TRU64      | 10  | Compaq TRU64 UNIX.
| ELFOSABI_MODESTO    | 11  | Novell Modesto.
| ELFOSABI_OPENBSD    | 12  | OpenBSD.
| ELFOSABI_ARM_AEABI  | 64  | ARM EABI.
| ELFOSABI_ARM        | 97  | ARM.
| ELFOSABI_STANDALONE | 255 | Standalone (embedded:) application.

`EI_ABIVERSION:`

Byte e_ident[EI_ABIVERSION] identifies the version of the ABI[^ABI] to which the
object is targeted. This field is used to distinguish among incompatible
versions of an ABI. The interpretation of this version number is dependent on
the ABI identified by the EI_OSABI field. If no values are specified for the
EI_OSABI field for the processor, or no version values are specified for the
ABI determined by a particular value of the EI_OSABI byte, the value zero is
used to indicate unspecified.

`EI_PAD:`

This value marks the beginning of the unused bytes in e_ident. These bytes are
reserved and are set to zero. Programs that read object files should ignore
these values.

## `Elf64_Shdr::sh_name`

| Name | Type | Attribute
| --- | --- | ---
| .got                | SHT_PROGBITS      | See Global Offset Table (Processor-Specific)
| .got.plt            | SHT_PROGBITS      | See Global Offset Table (Processor-Specific)
| .plt                | SHT_PROGBITS      | See Procedure Linkage Table (Processor-Specific)
| .plt.got            | SHT_PROGBITS      | See Procedure Linkage Table (Processor-Specific)
| .bss                | SHT_NOBITS        | SHF_ALLOC + SHF_WRITE
| .comment            | SHT_PROGBITS      | None
| .data, .data1       | SHT_PROGBITS      | SHF_ALLOC + SHF_WRITE
| .dynamic            | SHT_DYNAMIC       | SHF_ALLOC + SHF_WRITE
| .dynstr             | SHT_STRTAB        | SHF_ALLOC
| .dynsym             | SHT_DYNSYM        | SHF_ALLOC
| .eh_frame_hdr       | SHT_AMD64_UNWIND  | SHF_ALLOC
| .eh_frame           | SHT_AMD64_UNWIND  | SHF_ALLOC + SHF_WRITE
| .fini               | SHT_PROGBITS      | SHF_ALLOC + SHF_EXECINSTR
| .fini_array         | SHT_FINI_ARRAY    | SHF_ALLOC + SHF_WRITE
| .hash               | SHT_HASH          | SHF_ALLOC
| .init               | SHT_PROGBITS      | SHF_ALLOC + SHF_EXECINSTR
| .init_array         | SHT_INIT_ARRAY    | SHF_ALLOC + SHF_WRITE
| .interp             | SHT_PROGBITS      | See Program Interpreter
| .note               | SHT_NOTE          | None
| .lbss               | SHT_NOBITS        | SHF_ALLOC + SHF_WRITE + SHF_AMD64_LARGE
| .ldata, .ldata1     | SHT_PROGBITS      | SHF_ALLOC + SHF_WRITE + SHF_AMD64_LARGE
| .lrodata, .lrodata1 | SHT_PROGBITS      | SHF_ALLOC + SHF_AMD64_LARGE
| .preinit_array      | SHT_PREINIT_ARRAY | SHF_ALLOC + SHF_WRITE
| .rela               | SHT_RELA          | None
| .relname            | SHT_REL           | See Relocation Section
| .relaname           | SHT_RELA          | See Relocation Section
| .rodata, .rodata1   | SHT_PROGBITS      | SHF_ALLOC
| .shstrtab           | SHT_STRTAB        | None
| .strtab             | SHT_STRTAB        | Refer to the explanation following this table.
| .symtab             | SHT_SYMTAB        | See Symbol Table Section
| .symtab_shndx       | SHT_SYMTAB_SHNDX  | See Symbol Table Section
| .tbss               | SHT_NOBITS        | SHF_ALLOC + SHF_WRITE + SHF_TLS
| .tdata, .tdata1     | SHT_PROGBITS      | SHF_ALLOC + SHF_WRITE + SHF_TLS
| .text               | SHT_PROGBITS      | SHF_ALLOC + SHF_EXECINSTR
| .SUNW_bss           | SHT_NOBITS        | SHF_ALLOC + SHF_WRITE
| .SUNW_cap           | SHT_SUNW_cap      | SHF_ALLOC
| .SUNW_capchain      | SHT_SUNW_capchain | SHF_ALLOC
| .SUNW_capinfo       | SHT_SUNW_capinfo  | SHF_ALLOC
| .SUNW_heap          | SHT_PROGBITS      | SHF_ALLOC + SHF_WRITE
| .SUNW_ldynsym       | SHT_SUNW_LDYNSYM  | SHF_ALLOC
| .SUNW_dynsymsort    | SHT_SUNW_symsort  | SHF_ALLOC
| .SUNW_dymtlssort    | SHT_SUNW_tlssort  | SHF_ALLOC
| .SUNW_move          | SHT_SUNW_move     | SHF_ALLOC
| .SUNW_reloc         | SHT_REL SHT_RELA  | SHF_ALLOC
| .SUNW_syminfo       | SHT_SUNW_syminfo  | SHF_ALLOC
| .SUNW_version       | SHT_SUNW_verdef SHT_SUNW_verneed SHT_SUNW_versym | SHF_ALL

`.got`

GOT变量地址.

`.got.plt`

GOT函数地址.

`.plt`

PLT.

`.plt.got`

PLT.


## `Elf64_Shdr::sh_type`

| Name | Value | Description |
| --- | --- | --- |
| SHT_NULL          | 0  | The section header is inactive. It does not have an associated section.  Other members of the section header have undefined values. |
| SHT_PROGBITS      | 1  | This section holds information defined by the program, whose format and meaning are determined solely by the program. |
| SHT_SYMTAB <br> SHT_DYNSYM | 2 <br> 11 | These sections hold a symbol table, symbol table holds *Elf64_Sym* array for linker. |
| SHT_DYNAMIC       | 6  | This section holds a symbol table (*Elf64_Dyn* array) for link-editing. |
| SHT_STRTAB        | 3  | This section holds a string table (null-terminated string set). |
| SHT_REL           | 9  | This section holds *Elf32_Rel* array. |
| SHT_RELA          | 4  | This section holds *Elf32_Rela* array. |
| SHT_HASH          | 5  | This section holds a symbol hash table. |
| SHT_NOTE          | 7  | This section holds notes (ElfN_Nhdr). |
| SHT_NOBITS        | 8  | A section of this type occupies no space in the file. |
| SHT_SHLIB         | 10 | This section is reserved but has unspecified semantics. |
| SHT_INIT_ARRAY    | 14 | This section holds an array of pointers to initialization functions. |
| SHT_FINI_ARRAY    | 15 | This section holds an array of pointers to termination functions. |
| SHT_PREINIT_ARRAY | 16 | This section holds an array of pointers to functions that are invoked before all other initialization functions. |
| SHT_GROUP         | 17 |
| SHT_SYMTAB_SHNDX  | 18 | This section holds extended section indexes, that are associated with a symbol table. |
| SHT_LOPROC <br> SHT_HIPROC | 0x70000000 <br> 0x7fffffff | Reserved for processor-specific semantics. |
| SHT_LOUSER <br> SHT_HIUSER | 0x80000000 <br> 0xffffffff | Reserved for application programs. |
| SHT_LOOS <br> SHT_HIOS | 0x60000000 <br> 0x6fffffff | Reserved for operating system-specific semantics. |
| SHT_LOSUNW <br> SHT_HISUNW | 0x6fffffef <br> 0x6fffffff | Reserved for Oracle Solaris OS semantics. |
| SHT_SUNW_capchain | 0x6fffffef |
| SHT_SUNW_capinfo  | 0x6ffffff0 |
| SHT_SUNW_symsort  | 0x6ffffff1 |
| SHT_SUNW_tlssort  | 0x6ffffff2 |
| SHT_SUNW_LDYNSYM  | 0x6ffffff3 |
| SHT_SUNW_dof      | 0x6ffffff4 |
| SHT_SUNW_cap      | 0x6ffffff5 |
| SHT_SUNW_SIGNATURE| 0x6ffffff6 |
| SHT_SUNW_ANNOTATE | 0x6ffffff7 |
| SHT_SUNW_DEBUGSTR | 0x6ffffff8 |
| SHT_SUNW_DEBUG    | 0x6ffffff9 |
| SHT_SUNW_move     | 0x6ffffffa |
| SHT_SUNW_COMDAT   | 0x6ffffffb |
| SHT_SUNW_syminfo  | 0x6ffffffc |
| SHT_SUNW_verdef   | 0x6ffffffd |
| SHT_SUNW_verneed  | 0x6ffffffe |
| SHT_SUNW_versym   | 0x6fffffff |
| SHT_SPARC_GOTDATA | 0x70000000 |
| SHT_AMD64_UNWIND  | 0x70000001 |

`SHT_NULL`

> Identifies the section header as inactive. This section header does not have an associated section. Other members of the section header have undefined values.

节是未激活的.节头没有关联的节.节头的其它成员是示定义的.

`SHT_PROGBITS`

> Identifies information defined by the program, whose format and meaning are determined solely by the program.

标识程序定义的信息,其格式和意义完全由程序决定.

`SHT_SYMTAB`

表明节内容是 *Elf64_Sym* 结构序列.

> This section holds a symbol table.  Typically, SHT_SYMTAB provides symbols for link editing, though it may also be used for dynamic linking.  As a complete symbol table, it may contain many symbols unnecessary for dynamic linking.  An object file can also contain a SHT_DYNSYM section.
>
> 节保存 *Elf64_Sym* 表.为链接器提供符号,尽管它也被用途动态链接.作为一个完整的符号表,该表可以包含许多对于动态链接,不需要的符号.

`SHT_DYNSYM`

表明节内容是 *Elf64_Sym* 结构序列.

> This section holds a minimal set of dynamic linking symbols.  An object file can also contain a SHT_SYMTAB section.

`SHT_SUNW_LDYNSYM`

> Identifies a symbol table. Typically, a SHT_SYMTAB section provides symbols for link-editing. As a complete symbol table, the table can contain many symbols that are unnecessary for dynamic linking. Consequently, an object file can also contain a SHT_DYNSYM section, which holds a minimal set of dynamic linking symbols, to save space.
>
>一个符号表.通常,一个SHT_SYMTAB节为链接器提供符号.作为完整的符号表,该表可以包含许多不需要动态链接的符号.因此,对象文件也可以包含一个SHT_DYNSYM节,其中包含少许动态链接符号,以节省空间.
>
> SHT_DYNSYM can also be augmented with a SHT_SUNW_LDYNSYM section. This additional section provides local function symbols to the runtime environment, but is not required for dynamic linking. This section allows debuggers to produce accurate stack traces in runtime contexts when the non-allocable SHT_SYMTAB is not available, or has been stripped from the file. This section also provides the runtime environment with additional symbolic information for use with dladdr(3C).
>
> SHT_DYNSYM节可以通过SHT_SUNW_LDYNSYM节被增强.这额外的节为运行时环境提供了本地函数符号,这符号对于动态链接不是必需的.当不可分配的SHT_DYNSYM节不可用时或已从文件中剥离时,该节允许调试器在运行时上下文中生成精确的堆栈跟踪.这个节也为用户提供了运行时环境的额外符号信息,当使用dladrr(3C)时.
>
> When both a SHT_SUNW_LDYNSYM section and a SHT_DYNSYM section exist, the link-editor places their data regions immediately adjacent to each other. The SHT_SUNW_LDYNSYM section precedes the SHT_DYNSYM section. This placement allows the two tables to be viewed as a single larger contiguous symbol table, containing a reduced set of symbols from SHT_SYMTAB.
>
> 当SHT_SUNW_LDYNSYM节和SHT_DYNSYM节都存在时,链接编辑器将它们的数据区域彼此相邻.SHT_SUNW_LDYNSYM节先于SHT_DYNSYM节.这种布局允许将两个表视为一个较大的连续符号表,其中包含来自SHT_SYMTAB的一组减少的符号.
>
>See Symbol Table Section for details.

`SHT_STRTAB`

> Identifies a string table. An object file can have multiple string table sections.

标识一个字符串表.一个对象文件可以有多个字符串表节.

SHT_STRTAB类型的节储存的是c格式字符串的集合.

`SHT_REL`

> Identifies relocation entries without explicit addends, such as type Elf32_Rel for the 32–bit class of object files. An object file can have multiple Relocation Section. See Relocation Section for details.

`SHT_RELA`

> Identifies relocation entries with explicit addends, such as type Elf32_Rela for the 32–bit class of object files. An object file can have multiple Relocation Section. See Relocation Section for details.

`SHT_HASH`

`SHT_DYNAMIC`

> Identifies information for dynamic linking. Currently, an object file can have only one dynamic section. See Dynamic Section for details.

标识动态链接的信息.当前,一个对象文件只能有一个动态节.

`SHT_NOTE`
`SHT_NOBITS`

`SHT_SHLIB`
`SHT_INIT_ARRAY`
`SHT_FINI_ARRAY`
`SHT_PREINIT_ARRAY`
`SHT_GROUP`
`SHT_SYMTAB_SHNDX`
`SHT_LOOS`
`SHT_LOSUNW`
`SHT_SUNW_capchain`
`SHT_SUNW_capinfo`
`SHT_SUNW_symsort`
`SHT_SUNW_tlssort`
`SHT_SUNW_dof`
`SHT_SUNW_cap`
`SHT_SUNW_SIGNATURE`
`SHT_SUNW_ANNOTATE`
`SHT_SUNW_DEBUGSTR`
`SHT_SUNW_DEBUG`
`SHT_SUNW_move`
`SHT_SUNW_COMDAT`
`SHT_SUNW_syminfo`
`SHT_SUNW_verdef`
`SHT_SUNW_verneed`
`SHT_SUNW_versym`
`SHT_HISUNW`
`SHT_HIOS`
`SHT_LOPROC`
`SHT_SPARC_GOTDATA`
`SHT_AMD64_UNWIND`
`SHT_HIPROC`
`SHT_LOUSER`
`SHT_HIUSER`

## `Elf64_Shdr::sh_flags`

| Name | Value | Description
|---|---|---|
| SHF_WRITE      | 0x1 | Section should be writable during process execution.
| SHF_ALLOC      | 0x2 | Section occupies memory during process execution.
| SHF_EXECINSTR  | 0x4 | Section contains executable machine instructions.
| SHF_MERGE      | 0x10 | Section can be merged to eliminate duplication.
| SHF_STRINGS    | 0x20 | Section consists of null-terminated character strings.
| SHF_INFO_LINK  | 0x40 | *Elf64_shdr*::*sh_info* holds a section header table index.
| SHF_LINK_ORDER | 0x80 | Section adds special ordering requirements to the link-editor.
| SHF_OS_NONCONFORMING | 0x100 | Section requires special OS-specific processing beyond the standard linking rules to avoid incorrect behavior.
| SHF_GROUP      | 0x200 |
| SHF_TLS        | 0x400 | Section holds thread-local storage.
| SHF_MASKOS     | 0x0ff00000 | All bits are reserved for operating system-specific semantics.
| SHF_AMD64_LARGE| 0x10000000 |
| SHF_ORDERED    | 0x40000000 | Older version of the functionality provided by SHF_LINK_ORDER.
| SHF_EXCLUDE    | 0x80000000 | Section is excluded from input to the link-edit of an executable or shared object. This flag is ignored if the SHF_ALLOC flag is also set, or if relocations exist against the section.
| SHF_MASKPROC   | 0xf0000000 | All bits are reserved for processor-specific semantics.

## `Elf64_Shdr::sh_link`

| sh_type | sh_link | sh_info |
|---|---|---|
| SHT_DYNAMIC | Section header index of the associated string table. | 0
| SHT_HASH | Section header index of the associated symbol table. | 0
| SHT_REL <br> SHT_RELA | Section header index of the associated symbol table. | If the *sh_flags* contains the SHF_INFO_LINK flag, the section header index of the section to which the relocation applies, otherwise 0.
| SHT_SYMTAB <br> SHT_DYNSYM | Section header index of the associated string table. | One greater than the symbol table index of the last local symbol, STB_LOCAL.
| SHT_GROUP | Section header index of the associated symbol table. | The symbol table index of an entry in the associated symbol table. The name of the specified symbol table entry provides a signature for the section group.
| SHT_SYMTAB_SHNDX | Section header index of the associated symbol table. | 0


## `Elf64_Shdr::sh_info`

See <a href="#tc4-section-link-elf64_shdrsh_link">Elf64_Shdr::sh_link</a>.

## `Elf64_Dyn::d_tag`

| Name | Value | d_un | Executable  | Shared Object |
| --- | --- | --- | --- | --- |
| DT_NULL            |  0         | Ignored     | Mandatory   | Mandatory |
| DT_NEEDED          |  1         | d_val       | Optional    | Optional |
| DT_PLTRELSZ        |  2         | d_val       | Optional    | Optional |
| DT_PLTGOT          |  3         | d_ptr       | Optional    | Optional |
| DT_HASH            |  4         | d_ptr       | Mandatory   | Mandatory |
| DT_STRTAB          |  5         | d_ptr       | Mandatory   | Mandatory |
| DT_SYMTAB          |  6         | d_ptr       | Mandatory   | Mandatory |
| DT_RELA            |  7         | d_ptr       | Mandatory   | Optional |
| DT_RELASZ          |  8         | d_val       | Mandatory   | Optional |
| DT_RELAENT         |  9         | d_val       | Mandatory   | Optional |
| DT_STRSZ           | 10         | d_val       | Mandatory   | Mandatory |
| DT_SYMENT          | 11         | d_val       | Mandatory   | Mandatory |
| DT_INIT            | 12         | d_ptr       | Optional    | Optional |
| DT_FINI            | 13         | d_ptr       | Optional    | Optional |
| DT_SONAME          | 14         | d_val       | Ignored     | Optional |
| DT_RPATH           | 15         | d_val       | Optional    | Optional |
| DT_SYMBOLIC        | 16         | Ignored     | Ignored     | Optional |
| DT_REL             | 17         | d_ptr       | Mandatory   | Optional |
| DT_RELSZ           | 18         | d_val       | Mandatory   | Optional |
| DT_RELENT          | 19         | d_val       | Mandatory   | Optional |
| DT_PLTREL          | 20         | d_val       | Optional    | Optional |
| DT_DEBUG           | 21         | d_ptr       | Optional    | Ignored |
| DT_TEXTREL         | 22         | Ignored     | Optional    | Optional |
| DT_JMPREL          | 23         | d_ptr       | Optional    | Optional |
| DT_BIND_NOW        | 24         | Ignored     | Optional    | Optional |
| DT_INIT_ARRAY      | 25         | d_ptr       | Optional    | Optional |
| DT_FINI_ARRAY      | 26         | d_ptr       | Optional    | Optional |
| DT_INIT_ARRAYSZ    | 27         | d_val       | Optional    | Optional |
| DT_FINI_ARRAYSZ    | 28         | d_val       | Optional    | Optional |
| DT_RUNPATH         | 29         | d_val       | Optional    | Optional |
| DT_FLAGS           | 30         | d_val       | Optional    | Optional |
| DT_ENCODING        | 32         | Unspecified | Unspecified | Unspecified |
| DT_PREINIT_ARRAY   | 32         | d_ptr       | Optional    | Ignored |
| DT_PREINIT_ARRAYSZ | 33         | d_val       | Optional    | Ignored |
| DT_MAXPOSTAGS      | 34         | Unspecified | Unspecified | Unspecified |
| DT_LOOS            | 0x6000000d | Unspecified | Unspecified | Unspecified |
| DT_SUNW_AUXILIARY  | 0x6000000d | d_ptr       | Unspecified | Optional |
| DT_SUNW_RTLDINF    | 0x6000000e | d_ptr       | Optional    | Optional |
| DT_SUNW_FILTER     | 0x6000000e | d_ptr       | Unspecified | Optional |
| DT_SUNW_CAP        | 0x60000010 | d_ptr       | Optional    | Optional |
| DT_SUNW_SYMTAB     | 0x60000011 | d_ptr       | Optional    | Optional |
| DT_SUNW_SYMSZ      | 0x60000012 | d_val       | Optional    | Optional |
| DT_SUNW_ENCODING   | 0x60000013 | Unspecified | Unspecified | Unspecified |
| DT_SUNW_SORTENT    | 0x60000013 | d_val       | Optional    | Optional |
| DT_SUNW_SYMSORT    | 0x60000014 | d_ptr       | Optional    | Optional |
| DT_SUNW_SYMSORTSZ  | 0x60000015 | d_val       | Optional    | Optional |
| DT_SUNW_TLSSORT    | 0x60000016 | d_ptr       | Optional    | Optional |
| DT_SUNW_TLSSORTSZ  | 0x60000017 | d_val       | Optional    | Optional |
| DT_SUNW_CAPINFO    | 0x60000018 | d_ptr       | Optional    | Optional |
| DT_SUNW_STRPAD     | 0x60000019 | d_val       | Optional    | Optional |
| DT_SUNW_CAPCHAIN   | 0x6000001a | d_ptr       | Optional    | Optional |
| DT_SUNW_LDMACH     | 0x6000001b | d_val       | Optional    | Optional |
| DT_SUNW_CAPCHAINENT| 0x6000001d | d_val       | Optional    | Optional |
| DT_SUNW_CAPCHAINSZ | 0x6000001f | d_val       | Optional    | Optional |
| DT_HIOS            | 0x6ffff000 | Unspecified | Unspecified | Unspecified |
| DT_VALRNGLO        | 0x6ffffd00 | Unspecified | Unspecified | Unspecified |
| DT_CHECKSUM        | 0x6ffffdf8 | d_val       | Optional    | Optional |
| DT_PLTPADSZ        | 0x6ffffdf9 | d_val       | Optional    | Optional |
| DT_MOVEENT         | 0x6ffffdfa | d_val       | Optional    | Optional |
| DT_MOVESZ          | 0x6ffffdfb | d_val       | Optional    | Optional |
| DT_POSFLAG_1       | 0x6ffffdfd | d_val       | Optional    | Optional |
| DT_SYMINSZ         | 0x6ffffdfe | d_val       | Optional    | Optional |
| DT_SYMINENT        | 0x6ffffdff | d_val       | Optional    | Optional |
| DT_VALRNGHI        | 0x6ffffdff | Unspecified | Unspecified | Unspecified |
| DT_ADDRRNGLO       | 0x6ffffe00 | Unspecified | Unspecified | Unspecified |
| DT_CONFIG          | 0x6ffffefa | d_ptr       | Optional    | Optional |
| DT_DEPAUDIT        | 0x6ffffefb | d_ptr       | Optional    | Optional |
| DT_AUDIT           | 0x6ffffefc | d_ptr       | Optional    | Optional |
| DT_PLTPAD          | 0x6ffffefd | d_ptr       | Optional    | Optional |
| DT_MOVETAB         | 0x6ffffefe | d_ptr       | Optional    | Optional |
| DT_SYMINFO         | 0x6ffffeff | d_ptr       | Optional    | Optional |
| DT_ADDRRNGHI       | 0x6ffffeff | Unspecified | Unspecified | Unspecified |
| DT_RELACOUNT       | 0x6ffffff9 | d_val       | Optional    | Optional |
| DT_RELCOUNT        | 0x6ffffffa | d_val       | Optional    | Optional |
| DT_FLAGS_1         | 0x6ffffffb | d_val       | Optional    | Optional |
| DT_VERDEF          | 0x6ffffffc | d_ptr       | Optional    | Optional |
| DT_VERDEFNUM       | 0x6ffffffd | d_val       | Optional    | Optional |
| DT_VERNEED         | 0x6ffffffe | d_ptr       | Optional    | Optional |
| DT_VERNEEDNUM      | 0x6fffffff | d_val       | Optional    | Optional |
| DT_LOPROC          | 0x70000000 | Unspecified | Unspecified | Unspecified |
| DT_SPARC_REGISTER  | 0x70000001 | d_val       | Optional    | Optional |
| DT_AUXILIARY       | 0x7ffffffd | d_val       | Unspecified | Optional |
| DT_USED            | 0x7ffffffe | d_val       | Optional    | Optional |
| DT_FILTER          | 0x7fffffff | d_val       | Unspecified | Optional |
| DT_HIPROC          | 0x7fffffff | Unspecified | Unspecified | Unspecified |

`DT_NULL`

Marks the end of the _DYNAMIC array.

`DT_NEEDED`

The DT_STRTAB string table offset, specify a string, giving the name of a needed dependency. The dynamic array can contain multiple entries of this type. The relative order of these entries is significant, though their relation to entries of other types is not. See Shared Object Dependencies.

DT_STRTAB类型字符串表偏移,给出必需的依赖的名称.动态数组可以包含多个该类型的条目.这些条目的相对顺序是重要的,尽管它们与其他类型的条目没有关系.

`DT_PLTRELSZ`

The total size, in bytes, of the relocation entries associated with the procedure linkage table. See Procedure Linkage Table (Processor-Specific).

value. 指出PLT表的字节尺寸.

`DT_PLTGOT`

VA. An address associated with the procedure linkage table or the global offset table. See Procedure Linkage Table (Processor-Specific) and Global Offset Table (Processor-Specific).

虚拟地址,指出GOT或PLT在内存中的地址.

如何区分是GOT还是PLT? GOT应该是可写SHF_WRITE可分配SHF_ALLOC的;而PLT应该是可执行SHF_EXECINSTR可分配SHF_ALLOC的.

`DT_HASH`

The address of the symbol hash table. This table refers to the symbol table indicated by the DT_SYMTAB element. See Hash Table Section.

`DT_STRTAB`

VA. The address of the string table. Symbol names, dependency names, and other strings required by the runtime linker reside in this table. See String Table Section.

`DT_SYMTAB`

VA. The address of the symbol table that is associated with Dynamic Section and Dynamic Link. See Symbol Table Section.

`DT_RELA`

VA. The address of a relocation table. See Relocation Sections.

This element requires the DT_RELASZ and DT_RELAENT elements also be present. When relocation is mandatory for a file, either DT_RELA or DT_REL can occur.

VA. 指出重定位表在内存中的位置.


`DT_RELASZ`

The total size, in bytes, of the DT_RELA relocation table.

`DT_RELAENT`

The size, in bytes, of the DT_RELA relocation entry.

`DT_STRSZ`
The total size, in bytes, of the DT_STRTAB string table.

`DT_SYMENT`
The size, in bytes, of the DT_SYMTAB symbol entry.

`DT_INIT`

VA. The address of an initialization function. See Initialization and Termination Sections.

`DT_FINI`
VA. The address of a termination function. See Initialization and Termination Sections.

`DT_SONAME`

The DT_STRTAB string table offset of a null-terminated string, identifying the name of the shared object. See Recording a Shared Object Name.

`DT_RPATH`
The DT_STRTAB string table offset of a null-terminated library search path string. This element's use has been superseded by DT_RUNPATH. See Directories Searched by the Runtime Linker.

`DT_SYMBOLIC`

`DT_REL`

`DT_RELSZ`

`DT_RELENT`

`DT_PLTREL`

Indicates the type of relocation entry to which the procedure linkage table refers, either DT_REL or DT_RELA. All relocations in a procedure linkage table must use the same relocation. See Procedure Linkage Table (Processor-Specific). This element requires a DT_JMPREL element also be present.

value, DT_REL or DT_RELA. 由GOT表重定位的条目的重定位类型.

`DT_DEBUG`

Used for debugging.

`DT_TEXTREL`

`DT_JMPREL`

The address of relocation entries that are associated solely with the procedure linkage table. See Procedure Linkage Table (Processor-Specific). The separation of these relocation entries enables the runtime linker to ignore these entries when the object is loaded with lazy binding enabled. This element requires the DT_PLTRELSZ and DT_PLTREL elements also be present.

VA. 指出唯一一个与GOT关联的重定位表在内存中的地址. 这个重定位表条目会被运行时链接器忽略,以能lazy绑定.

`DT_BIND_NOW`

`DT_INIT_ARRAY`

The address of an array of pointers to initialization functions. This element requires that a DT_INIT_ARRAYSZ element also be present. See Initialization and Termination Sections.

`DT_FINI_ARRAY`

The address of an array of pointers to termination functions. This element requires that a DT_FINI_ARRAYSZ element also be present. See Initialization and Termination Sections.

`DT_INIT_ARRAYSZ`

The total size, in bytes, of the DT_INIT_ARRAY array.

`DT_FINI_ARRAYSZ`

The total size, in bytes, of the DT_FINI_ARRAY array.

`DT_RUNPATH`

`DT_FLAGS`

> Flag values specific to this object. See Table 13-9.

`DT_ENCODING`

`DT_PREINIT_ARRAY`

`DT_PREINIT_ARRAYSZ`

`DT_MAXPOSTAGS`

`DT_LOOS`

`DT_SUNW_AUXILIARY`

`DT_SUNW_RTLDINF`

`DT_SUNW_FILTER`

`DT_SUNW_CAP`

`DT_SUNW_SYMTAB`

`DT_SUNW_SYMSZ`

`DT_SUNW_ENCODING`

`DT_SUNW_SORTENT`

`DT_SUNW_SYMSORT`

`DT_SUNW_SYMSORTSZ`

`DT_SUNW_TLSSORT`

`DT_SUNW_TLSSORTSZ`

`DT_SUNW_CAPINFO`

`DT_SUNW_STRPAD`

`DT_SUNW_CAPCHAIN`

`DT_SUNW_LDMACH`

`DT_SUNW_CAPCHAINENT`

`DT_SUNW_CAPCHAINSZ`

`DT_HIOS`

`DT_VALRNGLO`

`DT_CHECKSUM`

`DT_PLTPADSZ`

`DT_MOVEENT`

`DT_MOVESZ`

`DT_POSFLAG_1`

`DT_SYMINSZ`

`DT_SYMINENT`

`DT_VALRNGHI`

`DT_ADDRRNGLO`

`DT_CONFIG`

`DT_DEPAUDIT`

`DT_AUDIT`

`DT_PLTPAD`

`DT_MOVETAB`

`DT_SYMINFO`

`DT_ADDRRNGHI`

`DT_RELACOUNT`

`DT_RELCOUNT`

`DT_FLAGS_1`

Flag values specific to this object. See Table 13-10.

`DT_VERDEF`

`DT_VERDEFNUM`

`DT_VERNEED`

The address of the version dependency table. Elements within this table contain indexes into the string table DT_STRTAB. This element requires that the DT_VERNEEDNUM element also be present. See Version Dependency Section.

这里指向了.gnu.version_r节.

`DT_VERNEEDNUM`

The number of entries in the DT_VERNEEDNUM table.

`DT_LOPROC`

`DT_SPARC_REGISTER`

`DT_AUXILIARY`

`DT_USED`

`DT_FILTER`

`DT_HIPROC`

## `ELF64_R_TYPE`

Calculation field see *Relocation Calculations*.

| Name | Value | Field | Calculation |
|---|---|---|---|
| R_AMD64_NONE      | 0  | None   | None
| R_AMD64_64        | 1  | word64 | S + A
| R_AMD64_PC32      | 2  | word32 | S + A - P
| R_AMD64_GOT32     | 3  | word32 | G + A
| R_AMD64_PLT32     | 4  | word32 | L + A - P
| R_AMD64_COPY      | 5  | None   | Refer to the explanation following this table.
| R_AMD64_GLOB_DAT  | 6  | word64 | S
| R_AMD64_JUMP_SLOT | 7  | word64 | S
| R_AMD64_RELATIVE  | 8  | word64 | B + A
| R_AMD64_GOTPCREL  | 9  | word32 | G + GOT + A - P
| R_AMD64_32        | 10 | word32 | S + A
| R_AMD64_32S       | 11 | word32 | S + A
| R_AMD64_16        | 12 | word16 | S + A
| R_AMD64_PC16      | 13 | word16 | S + A - P
| R_AMD64_8         | 14 | word8  | S + A
| R_AMD64_PC8       | 15 | word8  | S + A - P
| R_AMD64_PC64      | 24 | word64 | S + A - P
| R_AMD64_GOTOFF64  | 25 | word64 | S + A - GOT
| R_AMD64_GOTPC32   | 26 | word32 | GOT + A + P
| R_AMD64_SIZE32    | 32 | word32 | Z + A
| R_AMD64_SIZE64    | 33 | word64 | Z + A

`R_AMD64_NONE`

`R_AMD64_GOT32`

Computes the distance from the base of the GOT to the symbol's GOT entry. The relocation also instructs the link-editor to create a global offset table.

`R_AMD64_PLT32`

Computes the address of the symbol's procedure linkage table entry and instructs the link-editor to create a procedure linkage table.

`R_AMD64_COPY`

Created by the link-editor for dynamic executables to preserve a read-only text segment. The relocation offset member refers to a location in a writable segment. The symbol table index specifies a symbol that should exist both in the current object file and in a shared object. During execution, the runtime linker copies data associated with the shared object's symbol to the location specified by the offset. See Copy Relocations.

`R_AMD64_GLOB_DAT`

Used to set a GOT entry to the address of the specified symbol. The special relocation type enable you to determine the correspondence between symbols and GOT entries.

`R_AMD64_JUMP_SLOT`

Created by the link-editor for dynamic objects to provide lazy binding. The relocation offset member gives the location of a procedure linkage table entry. The runtime linker modifies the procedure linkage table entry to transfer control to the designated symbol address.

`R_AMD64_RELATIVE`

Created by the link-editor for dynamic objects. The relocation offset member gives the location within a shared object that contains a value representing a relative address. The runtime linker computes the corresponding virtual address by adding the virtual address at which the shared object is loaded to the relative address. Relocation entries for this type must specify a value of zero for the symbol table index.

`R_AMD64_GOTPCREL`

This relocations has different semantics from the R_AMD64_GOT32 or equivalent R_386_GOTPC relocation. The x64 architecture provides an addressing mode that is relative to the instruction pointer. Therefore, an address can be loaded from the GOT using a single instruction.

The calculation for the R_AMD64_GOTPCREL relocation provides the difference between the location in the GOT where the symbol's address is given, and the location where the relocation is applied.

`R_AMD64_GOTPC32`

Resembles R_386_PC32, except that it uses the address of the GOT in its calculation. The symbol referenced in this relocation normally is _GLOBAL_OFFSET_TABLE_, which also instructs the link-editor to create the global offset table.

`R_AMD64_GOTOFF64`

Computes the difference between a symbol's value and the address of the GOT. The relocation also instructs the link-editor to create the global offset table.

`R_AMD64_SIZE32`

`R_AMD64_SIZE64`

`R_AMD64_8`

These relocations are not conformant to the x64 ABI, but are added here for documentation purposes. The R_AMD64_8 relocation truncates the computed value to 8-bits. The R_AMD64_16 relocation truncates the computed value to 16-bits.

`R_AMD64_16`

See above.

`R_AMD64_32`

See above.

`R_AMD64_64`

See above.

`R_AMD64_PC8`

See above.

`R_AMD64_PC16`

See above.

`R_AMD64_PC32`

See above.

`R_AMD64_PC64`

See above.

`R_AMD64_32S`

The computed value is truncated to 32–bits. The link-editor verifies that the generated value for the relocation zero-extends to the original 64–bit value.

## `ELF64_R_SYM`

符号表索引值,来自于Elf64_Rela::r_info.得到值的方式为:

``` {class=line-numbers}
#define ELF64_R_SYM(info)             ((info)>>8)
#define ELF64_R_TYPE(info)            ((unsigned char)(info))
#define ELF32_R_INFO(sym, type)       (((sym)<<8)+(unsigned char)(type))

#define ELF64_R_SYM(info)             ((info)>>32)
#define ELF64_R_TYPE(info)            ((Elf64_Word)(info))
#define ELF64_R_INFO(sym, type)       (((Elf64_Xword)(sym)<<32)+ \
                                        (Elf64_Xword)(type))
```

## `Relocation Calculations`

The following notation is used to describe relocation computations:

| Notation | Description |
|---|---|
| A   | The addend used to compute the value of the relocatable field. <br> <br> *Elf64_Rel* 重定位前所在的地址的内容作为加数A; *Elf64_Rela* 时, *Elf64_Rela*::*r_addend* 作为加数A. |
| B   | The base address at which a shared object is loaded into memory during execution. Generally, a shared object file is built with a base virtual address of 0. However, the execution address of the shared object is different. See Program Header. |
| G   | The offset into the global offset table at which the address of the relocation entry's symbol resides during execution. See Global Offset Table (Processor-Specific). |
| GOT | The address of the global offset table. See Global Offset Table (Processor-Specific). |
| L   | The section offset or address of the procedure linkage table entry for a symbol. See Procedure Linkage Table (Processor-Specific). |
| P   | The section offset or address of the storage unit being relocated, computed using r_offset. <br> <br> 重定位后所在的地址作为P. |
| S   | The value of the symbol whose index resides in the relocation entry. <br> <br> *Elf64_Sym::st_value* 作为S. |
| Z   | The size of the symbol whose index resides in the relocation entry. |

## `Elf64_Ehdr::e_shnum`

| Name | Value | Description |
|---|---|---|
| SHN_UNDEF         | 0      | An undefined, missing, irrelevant, or otherwise meaningless section reference.
| SHN_LORESERVE <br> SHN_HIRESERVE | 0xff00 <br> 0xffff | The lower/upper boundary of the range of reserved indexes.
| SHN_LOPROC <br> SHN_HIPROC | 0xff00 <br> 0xff1f | Reserved for processor-specific semantics.
| SHN_ABS           | 0xfff1 | Absolute values for the corresponding reference.
| SHN_COMMON        | 0xfff2 | Symbols defined relative to this section are common symbols.
| SHN_XINDEX        | 0xffff | If section header index is greater than or equal to SHN_LORESERVE, *Elf64_Ehdr::e_shstrndx* has the value SHN_XINDEX; And the actual index is contained in the *Elf64::shdr::sh_link* of the section header.

## `Elf64_Ehdr::e_shstrndx`

See *Elf64_Ehdr::e_shnum*.

## `Elf64_Sym::st_shndx`

See *Elf64_Ehdr::e_shnum*.

## `ELF64_ST_TYPE`

| Name | Value | Description |
|---|---|---|
| STT_NOTYPE  | 0  | The symbol type is not specified. |
| STT_OBJECT  | 1  | This symbol is associated with a data object, such as a variable, an array, and so forth. |
| STT_FUNC    | 2  | This symbol is associated with a function or other executable code. |
| STT_SECTION | 3  | This symbol is associated with a section. Symbol table entries of this type exist primarily for relocation and normally have STB_LOCAL binding. |
| STT_FILE    | 4  | Conventionally, the symbol's name gives the name of the source file that is associated with the object file. A file symbol has STB_LOCAL binding and a section index of SHN_ABS. This symbol, if present, precedes the other STB_LOCAL symbols for the file. <br> <br> Symbol index 1 of the SHT_SYMTAB is an STT_FILE symbol representing the object file. Conventionally, this symbol is followed by the files STT_SECTION symbols. These section symbols are then followed by any global symbols that have been reduced to locals. |
| STT_COMMON  | 5  | This symbol labels an uninitialized common block. This symbol is treated exactly the same as STT_OBJECT. |
| STT_TLS     | 6  | The symbol specifies a thread-local storage entity. When defined, this symbol gives the assigned offset for the symbol, not the actual address. <br> <br> Thread-local storage relocations can only reference symbols with type STT_TLS. A reference to a symbol of type STT_TLS from an allocatable section, can only be achieved by using special thread-local storage relocations. See Chapter 14, Thread-Local Storage for details. A reference to a symbol of type STT_TLS from a non-allocatable section does not have this restriction. |
| STT_LOOS <br> STT_HIOS | 10 <br> 12 | Reserved for operating system-specific semantics. |
| STT_LOPROC <br> STT_HIPROC | 13 <br> 15 | Reserved for processor-specific semantics. |

## `ELF64_ST_BIND`

| Name       | Value | Description |
|---|---|---|
| STB_LOCAL  | 0  | Local symbol. These symbols are not visible outside the object file containing their definition. Local symbols of the same name can exist in multiple files without interfering with each other. <br> 本地符号.这些符号,在包含其定义的对象文件之外,是不可见的.相同名字的本地符号可以存在多个文件中,且相互不干预. |
| STB_GLOBAL | 1  | Global symbols. These symbols are visible to all object files being combined. One file's definition of a global symbol satisfies another file's undefined reference to the same global symbol. <br> 全局符号.这些符号,对于正在组合的所有对象文件,是可见的.一个文件中全局符号的定义消除其它文件对于该符号的未定义的引用. |
| STB_WEAK   | 2  | Weak symbols. These symbols resemble global symbols, but their definitions have lower precedence. <br> 弱符号. 类似于全局符号,但是有一个低的优先权. |
| STB_LOOS <br> STB_HIOS | 10 <br> 12 | Reserved for operating system-specific. |semantics. |
| STB_LOPROC <br> STB_HIPROC | 13 <br> 15 | Reserved for processor-specific semantics. |

Global symbols and weak symbols differ in two major ways:

- When the link-editor combines several relocatable object files, multiple definitions of STB_GLOBAL symbols with the same name are not allowed. However, if a defined global symbol exists, the appearance of a weak symbol with the same name does not cause an error. The link-editor honors the global definition and ignores the weak definitions.

    Similarly, if a common symbol exists, the appearance of a weak symbol with the same name does not cause an error. The link-editor uses the common definition and ignores the weak definition. A common symbol has the st_shndx field holding SHN_COMMON. See Symbol Resolution.

- When the link-editor searches archive libraries, archive members that contain definitions of undefined or tentative global symbols are extracted. The member's definition can be either a global or a weak symbol.

  The link-editor, by default, does not extract archive members to resolve undefined weak symbols. Unresolved weak symbols have a zero value. The use of -z weakextract overrides this default behavior. This options enables weak references to cause the extraction of archive members.

## `DT_FLAGS`

| Name | Value| Meaning |
|---|---|---|
| DF_ORIGIN     | 0x1  | $ORIGIN processing required |
| DF_SYMBOLIC   | 0x2  | Symbolic symbol resolution required |
| DF_TEXTREL    | 0x4  | Text relocations exist |
| DF_BIND_NOW   | 0x8  | Non-lazy binding required |
| DF_STATIC_TLS | 0x10 | Object uses static thread-local storage scheme |

`DF_ORIGIN`
Indicates that the object requires $ORIGIN processing. See Locating Associated Dependencies.
``` {class=line-numbers}
$ ldd -s abc
....
find object=libA.so.1; required by abc
search path=$ORIGIN/../lib  (RUNPATH/RPATH from file abc)
  trying path=/usr/local/ABC/lib/libA.so.1
    libA.so.1 =>     /usr/local/ABC/lib/libA.so.1

find object=libB.so.1; required by /usr/local/ABC/lib/libA.so.1
search path=$ORIGIN  (RUNPATH/RPATH from file /usr/local/ABC/lib/libA.so.1)
  trying path=/usr/local/ABC/lib/libB.so.1
    libB.so.1 =>     /usr/local/ABC/lib/libB.so.1
```

`DF_SYMBOLIC`
Indicates that the object contains symbolic bindings that were applied during its link-edit. See Using the -B symbolic Option.

`DF_TEXTREL`
Indicates that one or more relocation entries might request modifications to a non-writable segment, and the runtime linker can prepare accordingly. See Position-Independent Code.

`DF_BIND_NOW`
Indicates that all relocations for this object must be processed before returning control to the program. The presence of this entry takes precedence over a directive to use lazy binding when specified through the environment or by means of dlopen(3C). See When Relocations Are Performed.

`DF_STATIC_TLS`
Indicates that the object contains code using a static thread-local storage scheme. Static thread-local storage should not be used in objects that are dynamically loaded, either using dlopen(3C), or using lazy loading.

# `Example Collection`

## `Analyze Relocation`

``` {class=line-numbers}
#include <stdio.h>


int Add(int a, int b)
{
        return a + b;
}

int main(int argc, const char** argv)
{
        int i = Add(2 , 3);
        printf("i = %d\n", i);

        return 0;
}
```

`Analyze Relocation of Relocateable Object`

1. generate Relocateable Object

    ``` {class=line-numbers}
    gcc -g -c -o main.o main.c
    ```

2. view Elf64_Ehdr

    ``` {class=line-numbers}
    hexdump -C -n 64 main.o
    00000000  7f 45 4c 46 02 01 01 00  00 00 00 00 00 00 00 00
    00000010  01 00 3e 00 01 00 00 00  00 00 00 00 00 00 00 00
    00000020  00 00 00 00 00 00 00 00  30 09 00 00 00 00 00 00
    00000030  00 00 00 00 40 00 00 00  00 00 40 00 15 00 12 00

    e_ident[EI_NIDENT] = 7f 45 4c 46 02 01 01 00  00 00 00 00 00 00 00 00
        e_ident[EI_MAG0]        = 0x7f
        e_ident[EI_MAG1]        = 0x45
        e_ident[EI_MAG2]        = 0x4c
        e_ident[EI_MAG3]        = 0x46
        e_ident[EI_CLASS]       = 0x2
        e_ident[EI_DATA]        = 0x1
        e_ident[EI_VERSION]     = 0x1
        e_ident[EI_OSABI]       = 0x0
        e_ident[EI_ABIVERSION]  = 0x0
        e_ident[EI_PAD]         = 0x00 0x00 0x00 0x00 0x00 0x00
        e_ident[EI_NIDENT]      = 0x0
    e_type            = 0x1
    e_machine         = 0x3e
    e_version         = 0x1
    e_entry           = 0x0
    e_phoff           = 0x0
    e_shoff           = 0x930
    e_flags           = 0x0
    e_ehsize          = 0x40
    e_phentsize       = 0x0
    e_phnum           = 0x0
    e_shentsize       = 0x40
    e_shnum           = 0x15
    e_shstrndx        = 0x12
    ```

3. find relocation sections

    ``` {class=line-numbers}
    readelf -S main.o | grep REL
      [ 2] .rela.text        RELA             0000000000000000  000005e0
      [ 7] .rela.debug_info  RELA             0000000000000000  00000628
      [10] .rela.debug_arang RELA             0000000000000000  00000808
      [12] .rela.debug_line  RELA             0000000000000000  00000838
      [17] .rela.eh_frame    RELA             0000000000000000  00000850
    ```

4. get relocation section header 2

    ``` {class=line-numbers}
    hexdump -C -s0x9b0 -n64 main.o
    000009b0  1b 00 00 00 04 00 00 00  40 00 00 00 00 00 00 00
    000009c0  00 00 00 00 00 00 00 00  e0 05 00 00 00 00 00 00
    000009d0  48 00 00 00 00 00 00 00  13 00 00 00 01 00 00 00
    000009e0  08 00 00 00 00 00 00 00  18 00 00 00 00 00 00 00

    sh_name       = 0x1b
    sh_type       = 0x4
    sh_flags      = 0x40
    sh_addr       = 0x0
    sh_offset     = 0x5e0
    sh_size       = 0x48
    sh_link       = 0x13
    sh_info       = 0x1
    sh_addralign  = 0x8
    sh_entsize    = 0x18
    ```

5. get relocation entries

    ``` {class=line-numbers}
    hexdump -C -s0x5e0 -n72 main.o
    000005e0  2e 00 00 00 00 00 00 00  02 00 00 00 0e 00 00 00
    000005f0  fc ff ff ff ff ff ff ff  3b 00 00 00 00 00 00 00
    00000600  0a 00 00 00 05 00 00 00  00 00 00 00 00 00 00 00
    00000610  45 00 00 00 00 00 00 00  02 00 00 00 10 00 00 00
    00000620  fc ff ff ff ff ff ff ff

    R1:
        r_offset    = 0x2e
        r_info      = 0x0000000e00000002
        r_addend    = 0xfffffffffffffffc
        ELF64_R_TYPE=0x2  sh_info=0x1
        ELF64_R_SYM=0xe  sh_link=0x13

    R2:
        r_offset    = 0x3b
        r_info      = 0x000000050000000a
        r_addend    = 0x0
        ELF64_R_TYPE=0xa  sh_info=0x1
        ELF64_R_SYM=0x5  sh_link=0x13

    R3:
        r_offset    = 0x45
        r_info      = 0x0000001000000002
        r_addend    = 0xfffffffffffffffc
        ELF64_R_TYPE=0x2  sh_info=0x1
        ELF64_R_SYM=0x10  sh_link=0x13
    ```

6. get section header x01 and 0x13

    ``` {class=line-numbers}
    readelf -S ./main.o
    Section Headers:
      [Nr] Name              Type             Address           Offset
          Size              EntSize          Flags  Link  Info  Align
        [ 1] .text             PROGBITS         0000000000000000  00000040
            0000000000000050  0000000000000000  AX       0     0     1
        [19] .symtab           SYMTAB           0000000000000000  00000430
          0000000000000198  0000000000000018          20    14     8
    ```

7. get symbol

    ``` {class=line-numbers}
    S1:
        ELF64_R_SYM=0xe  sh_link=0x13
        0x430 + 0x18 * 0xe = 0x580

        hexdump -C -s0x580 -n24 ./main.o
        00000580  08 00 00 00 12 00 01 00  00 00 00 00 00 00 00 00
        00000590  14 00 00 00 00 00 00 00

        st_name   = 0x8
        st_info   = 0x12
        st_other  = 0x0
        st_shndx  = 0x1
        st_value  = 0x0
        st_size   = 0x14

        ELF32_ST_TYPE = 0x2     STT_FUNC
        ELF32_ST_BIND = 0x1     STB_GLOBAL

    S2:
        ELF64_R_SYM=0x5  sh_link=0x13
        0x430 + 0x18 * 0x5 = 0x4a8

        hexdump -C -s0x4a8 -n24 ./main.o
        000004a8  00 00 00 00 03 00 05 00  00 00 00 00 00 00 00 00
        000004b8  00 00 00 00 00 00 00 00

        st_name   = 0x0
        st_info   = 0x3
        st_other  = 0x0
        st_shndx  = 0x5
        st_value  = 0x0
        st_size   = 0x0

        ELF32_ST_TYPE = 0x3     STT_SECTION
        ELF32_ST_BIND = 0x0     STB_LOCAL

    S3:
        ELF64_R_SYM=0x10  sh_link=0x13
        0x430 + 0x18 * 0x10 = 0x5b0

        hexdump -C -s0x5b0 -n24 ./main.o
        000005b0  11 00 00 00 10 00 00 00  00 00 00 00 00 00 00 00
        000005c0  00 00 00 00 00 00 00 00

        st_name   = 0x11
        st_info   = 0x10
        st_other  = 0x0
        st_shndx  = 0x0
        st_value  = 0x0
        st_size   = 0x0

        ELF32_ST_TYPE = 0x0     STT_NOTYPE
        ELF32_ST_BIND = 0x1     STB_GLOBAL
    ```

8. get strings

    ``` {class=line-numbers}
    readelf -S ./main.o
    Section Headers:
      [Nr] Name              Type             Address           Offset
          Size              EntSize          Flags  Link  Info  Align
      [20] .strtab           STRTAB           0000000000000000  000005c8
          0000000000000018  0000000000000000           0     0     1

    Str1:
        0x5c8 + 0x8 = 0x5d0
        hexdump -C -s0x5d0 -n10 ./main.o
        000005d0  41 64 64 00 6d 61 69 6e  00 70                    |Add.main.p|

    Str2:
        0x5c8 + 0 = 0x5c8
        hexdump -C -s0x5c8 -n10 ./main.o
        000005c8  00 6d 61 69 6e 2e 63 00  41 64                    |.main.c.Ad|

    Str3:
        0x5c8 + 0x11 = 0x5d9
        hexdump -C -s0x5d9 -n10 ./main.o
        000005d9  70 72 69 6e 74 66 00 2e  00 00                    |printf....|
    ```

8. get relocation position

    ``` {class=line-numbers}
    R1:
        r_offset    = 0x2e
        r_info      = 0x0000000e00000002
        r_addend    = 0xfffffffffffffffc
        ELF64_R_TYPE=0x2  sh_info=0x1
        ELF64_R_SYM=0xe  sh_link=0x13
        symbolname: Add
    S1:
        st_name   = 0x8
        st_info   = 0x12
        st_other  = 0x0
        st_shndx  = 0x1
        st_value  = 0x0
        st_size   = 0x14

        relocation section header index = sh_info = 0x1
        relocation section offset = r_offset = 0x2e

    R2:
        r_offset    = 0x3b
        r_info      = 0x000000050000000a
        r_addend    = 0x0
        ELF64_R_TYPE=0xa  sh_info=0x1
        ELF64_R_SYM=0x5  sh_link=0x13
        symbolname: 0
    S2:
        st_name   = 0x0
        st_info   = 0x3
        st_other  = 0x0
        st_shndx  = 0x5
        st_value  = 0x0
        st_size   = 0x0

        relocation section header index = sh_info = 0x1
        relocation section offset = r_offset = 0x3b

    R3:
        r_offset    = 0x45
        r_info      = 0x0000001000000002
        r_addend    = 0xfffffffffffffffc
        ELF64_R_TYPE=0x2  sh_info=0x1
        ELF64_R_SYM=0x10  sh_link=0x13
        symbolname: printf
    S3:
        st_name   = 0x11
        st_info   = 0x10
        st_other  = 0x0
        st_shndx  = 0x0
        st_value  = 0x0
        st_size   = 0x0

        relocation section header index = sh_info = 0x1
        relocation section offset = r_offset = 0x45
    ```

    ``` {class=line-numbers}
    objdump -d ./main.o
    ./main.o:     file format elf64-x86-64
    Disassembly of section .text:
    0000000000000000 <Add>:
      0:  55                    push   %rbp
      1:  48 89 e5              mov    %rsp,%rbp
      4:  89 7d fc              mov    %edi,-0x4(%rbp)
      7:  89 75 f8              mov    %esi,-0x8(%rbp)
      a:  8b 55 fc              mov    -0x4(%rbp),%edx
      d:  8b 45 f8              mov    -0x8(%rbp),%eax
      10: 01 d0                 add    %edx,%eax
      12: 5d                    pop    %rbp
      13: c3                    retq
    0000000000000014 <main>:
      14: 55                    push   %rbp
      15: 48 89 e5              mov    %rsp,%rbp
      18: 48 83 ec 20           sub    $0x20,%rsp
      1c: 89 7d ec              mov    %edi,-0x14(%rbp)
      1f: 48 89 75 e0           mov    %rsi,-0x20(%rbp)
      23: be 03 00 00 00        mov    $0x3,%esi
      28: bf 02 00 00 00        mov    $0x2,%edi
      2d: e8 00 00 00 00        callq  32 <main+0x1e>
      32: 89 45 fc              mov    %eax,-0x4(%rbp)
      35: 8b 45 fc              mov    -0x4(%rbp),%eax
      38: 89 c6                 mov    %eax,%esi
      3a: bf 00 00 00 00        mov    $0x0,%edi
      3f: b8 00 00 00 00        mov    $0x0,%eax
      44: e8 00 00 00 00        callq  49 <main+0x35>
      49: b8 00 00 00 00        mov    $0x0,%eax
      4e: c9                    leaveq
      4f: c3                    retq
    ```

    ``` {class=line-numbers}
    R1:
        relocation section header index = sh_info = 0x1
        relocation section offset = r_offset = 0x2e
        symbolname: Add

    R2:
        relocation section header index = sh_info = 0x1
        relocation section offset = r_offset = 0x3b
        symbolname: 0  ==> "%s\n"

    R3:
        relocation section header index = sh_info = 0x1
        relocation section offset = r_offset = 0x45
        symbolname: printf


    在可重定位文件中,是没有程序头的,也就没有内存布局,因为所有的都会整合到库或执行程序中.
    在整合中可能不保持相对偏移?非本函数域内的引用自然要重定位了.所以:
    Add() printf() "%s\n" 这三个引用要重定位了.
    如果,在链接时,保持main()与Add()的内存布局,那么这个Add()调用可以用相对call完成.但是
    可重定位文件没有这样做,可能整合时,是以引用为单位操作.
    ```

`Analyze Relocation of Shared Object`

- generate Relocateable Object

  ``` {class=line-numbers}
  gcc -g -shared -fPIC -o main.so main.c
  ```

- get relocation entries

  ``` {class=line-numbers}
  readelf -S ./main.so | grep REL
  [ 7] .rela.dyn         RELA             0000000000000490  00000490
  [ 8] .rela.plt         RELA             0000000000000550  00000550
  ```

  ``` {class=line-numbers}
  section_table_element[7]
  s_name      = 0x64
  s_type      = 0x04
  s_flags     = 0x02
  s_addr      = 0x0000000000000490
  s_offset    = 0x0490
  s_size      = 0xc0
  s_link      = 0x03
  s_info      = 0x00
  s_addralign = 0x08
  s_entsize   = 0x18

  section_table_element[8]
  s_name      = 0x6e
  s_type      = 0x04
  s_flags     = 0x42
  s_addr      = 0x0000000000000550
  s_offset    = 0x550
  s_size      = 0x30
  s_link      = 0x03
  s_info      = 0x16
  s_addralign	= 0x08
  s_entsize   = 0x18
  ```

  ``` {class=line-numbers}
  section_table_element[7]
  00 0E 20 00  00 00 00 00    08 00 00 00  00 00 00 00
  B0 06 00 00  00 00 00 00    08 0E 20 00  00 00 00 00
  08 00 00 00  00 00 00 00    70 06 00 00  00 00 00 00
  28 10 20 00  00 00 00 00    08 00 00 00  00 00 00 00
  28 10 20 00  00 00 00 00    D8 0F 20 00  00 00 00 00
  06 00 00 00  02 00 00 00    00 00 00 00  00 00 00 00
  E0 0F 20 00  00 00 00 00    06 00 00 00  04 00 00 00
  00 00 00 00  00 00 00 00    E8 0F 20 00  00 00 00 00
  06 00 00 00  05 00 00 00    00 00 00 00  00 00 00 00
  F0 0F 20 00  00 00 00 00    06 00 00 00  06 00 00 00
  00 00 00 00  00 00 00 00    F8 0F 20 00  00 00 00 00
  06 00 00 00  07 00 00 00    00 00 00 00  00 00 00 00

    R[0]
      r_offset = 0x20e000
      r_info   = 0x08
      r_addend = 0x06b0

    R[1]
      r_offset = 0x20e008
      r_info   = 0x08
      r_addend = 0x0670

    R[2]
      r_offset = 0x201028
      r_info   = 0x08
      r_addend = 0x201028

    R[3]
      r_offset = 0x200fd8
      r_info   = 0x0200000006
      r_addend = 0x00

    R[4]
      r_offset = 0x200fe0
      r_info   = 0x0400000006
      r_addend = 0x00

    R[5]
      r_offset = 0x200fe8
      r_info   = 0x0500000006
      r_addend = 0x00

    R[6]
      r_offset = 0x200ff0
      r_info   = 0x0600000006
      r_addend = 0x00

    R[7]
      r_offset = 0x200ff8
      r_info   = 0x0700000006
      r_addend = 0x00

  section_table_element[8]
  18 10 20 00 00 00 00 00 07 00 00 00 03 00 00 00
  00 00 00 00 00 00 00 00 20 10 20 00 00 00 00 00
  07 00 00 00 0C 00 00 00 00 00 00 00 00 00 00 00

    R[8]
      r_offset = 0x201018
      r_info   = 0x0300000007
      r_addend = 0x00

    R[9]
      r_offset = 0x201020
      r_info   = 0x0c00000007
      r_addend = 0x00

  ```

  ``` {class=line-numbers}
  R[4]
    r_offset = 0x200fe0
    r_info   = 0x0400000006
    r_addend = 0x00

  R[8]
    r_offset = 0x201018
    r_info   = 0x0300000007
    r_addend = 0x00

  R[9]
    r_offset = 0x201020
    r_info   = 0x0c00000007
    r_addend = 0x00
  ```

- get strings

  ``` {class=line-numbers}
  R[4]
    r_offset = 0x200fe0
    r_info   = 0x0400000006
    r_addend = 0x00
    __gmon_start__

  R[8]
    r_offset = 0x201018
    r_info   = 0x0300000007
    r_addend = 0x00
    printf@GLIBC_2.2.5

  R[9]
    r_offset = 0x201020
    r_info   = 0x0c00000007
    r_addend = 0x00
    Add
  ```

- get address

  ``` {class=line-numbers}
  R[4]
    r_offset = 0x200fe0
    r_info   = 0x0400000006
    r_addend = 0x00
    __gmon_start__
    重定位地址 = 0x200fe0

  R[8]
    r_offset = 0x201018
    r_info   = 0x0300000007
    r_addend = 0x00
    printf@GLIBC_2.2.5
    重定位地址 = 0x201018

  R[9]
    r_offset = 0x201020
    r_info   = 0x0c00000007
    r_addend = 0x00
    Add
    重定位地址 = 0x201020
  ```

  ``` {class=line-numbers}
  Disassembly of section .init:
    0000000000000580 <_init>:
    580:	48 83 ec 08          	sub    $0x8,%rsp
    584:	48 8b 05 55 0a 20 00 	mov    0x200a55(%rip),%rax        # 200fe0 <_DYNAMIC+0x1c8>
    58b:	48 85 c0             	test   %rax,%rax
    58e:	74 05                	je     595 <_init+0x15>
    590:	e8 3b 00 00 00       	callq  5d0 <Add@plt+0x10>
    595:	48 83 c4 08          	add    $0x8,%rsp
    599:	c3                   	retq

  Disassembly of section .plt:
    00000000000005b0 <printf@plt>:
    5b0:	ff 25 62 0a 20 00    	jmpq   *0x200a62(%rip)        # 201018 <_GLOBAL_OFFSET_TABLE_+0x18>
    5b6:	68 00 00 00 00       	pushq  $0x0
    5bb:	e9 e0 ff ff ff       	jmpq   5a0 <_init+0x20>

    00000000000005c0 <Add@plt>:
    5c0:	ff 25 5a 0a 20 00    	jmpq   *0x200a5a(%rip)        # 201020 <_GLOBAL_OFFSET_TABLE_+0x20>
    5c6:	68 01 00 00 00       	pushq  $0x1
    5cb:	e9 d0 ff ff ff       	jmpq   5a0 <_init+0x20>
    objdump -d ./main.so
  ```

`Analyze Relocation of Executable Object`

## `plt`

``` {class=line-numbers}
// main.c
#include <stdio.h>


int main()
{
    printf("%d\n", Add(2, 3));
    return 0;
}
```

``` {class=line-numbers}
// Add.c
int Add(int a, int b)
{
    return a + b;
}

```

``` {class=line-numbers}
gcc -g -O0 -shared -fPIC -o libadd.so Add.c
gcc -g -O0 -o main main.c -ladd -L`pwd`
export LD_LIBRARY_PATH=`pwd`
```

``` {class=line-numbers}
```

# `Concept`

## `ELF Header`

**ELF Header** resides at the beginning of an object file and holds a road map describing the file's organization.

**Note:** Only the ELF header has a fixed position in the file. The flexibility of the ELF format requires no specified order for header tables, sections or segments. However, this figure is typical of the layout used in the Oracle Solaris OS.

## `Sections`

**Sections** represent the smallest indivisible units that can be processed within an ELF file.

Sections hold the bulk of object file information for the linking view. This data includes instructions, data, symbol table, and relocation information.
Descriptions of sections appear in the first part of this chapter. The second part of this chapter discusses segments and the program execution view of the file.

## `Section Header Table`

**Section Header Table** contains information describing the file's sections. Every section has an entry in the table. Each entry gives information such as the section name and section size. Files that are used in link-editing must have a section header table.

## `Segments`

**Segments** are a collection of sections. Segments represent the smallest individual units that can be mapped to a memory image by exec(2) or by the runtime linker.

## `Program Header Table`

**Program Header Table**, if present, tells the system how to create a process image. Files used to generate a process image, executable files and shared objects, must have a program header table. Relocatable object files do not need a program header table.

# `Abbreviations`

## `ELF`

Executable and Linking Format[^1].

## `ABI`

Application Binary Interfaces.

# `Footnotes`

[^1]: sakfskf