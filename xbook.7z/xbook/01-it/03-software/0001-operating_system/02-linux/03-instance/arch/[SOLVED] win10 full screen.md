1. setting of win10 vm in virtualbox.
2. storage:
   add /usr/lib/virtualbox/additions/VBoxGuestAdditions.iso to IDE controller
   if not, /usr/lib/virtualbox/additions/VBoxGuestAdditions.iso, 
   pacman -S virtualbox-guest-iso.
3. install VBoxWindowsAdditions in device mounted.

