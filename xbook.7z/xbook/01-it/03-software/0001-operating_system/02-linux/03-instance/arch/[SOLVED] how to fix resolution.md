***
[toc]
***

# `View Resolution Configuration`

``` {class=line-numbers}
[eit@eit-hostname ~]$ xrandr
Screen 0: minimum 320 x 200, current 1024 x 768, maximum 8192 x 8192
Virtual-1 connected primary 1024x768+0+0 (normal left inverted right x axis y axis) 0mm x 0mm
   preferred     60.00 +
   2560x1600     59.99
   1920x1440     60.00
   1856x1392     60.00
   1792x1344     60.00
   1920x1200     59.88
   1600x1200     60.00
   1680x1050     59.95
   1400x1050     59.98
   1280x1024     60.02
   1440x900      59.89
   1280x960      60.00
   1360x768      60.02
   1280x800      59.81
   1152x864      75.00
   1280x768      59.87
   1024x768      60.00*
   800x600       60.32
   640x480       59.94
Virtual-2 disconnected (normal left inverted right x axis y axis)
Virtual-3 disconnected (normal left inverted right x axis y axis)
Virtual-4 disconnected (normal left inverted right x axis y axis)
Virtual-5 disconnected (normal left inverted right x axis y axis)
Virtual-6 disconnected (normal left inverted right x axis y axis)
Virtual-7 disconnected (normal left inverted right x axis y axis)
Virtual-8 disconnected
```

**Virtual-1** is connected primary, and has no the resolusion 1920*1080.

# `Add expected resolution`

``` {class=line-numbers}
[eit@eit-hostname ~]$ cvt 1920 1080
# 1920x1080 59.96 Hz (CVT 2.07M9) hsync: 67.16 kHz; pclk: 173.00 MHz
Modeline "1920x1080_60.00"  173.00  1920 2048 2248 2576  1080 1083 1088 1120 -hsync +vsync
[eit@eit-hostname ~]$ xrandr --newmode "1920x1080_60.00"  173.00  1920 2048 2248 2576  1080 1083 1088 1120 -hsync +vsync

[eit@eit-hostname ~]$ xrandr --addmode Virtual-1 "1920x1080_60.00"

[eit@eit-hostname ~]$ xrandr -s 1920x1080
```