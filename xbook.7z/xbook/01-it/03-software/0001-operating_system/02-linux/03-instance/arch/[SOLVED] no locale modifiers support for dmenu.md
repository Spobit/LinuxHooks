```
# echo  >> /etc/profile
# echo # [SOLVED] no locale modifiers support for dmenu >> /etc/profile
# echo export LC_ALL=en_US.UTF-8 >> /etc/profile
```

