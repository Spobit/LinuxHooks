***
[toc]
***

#　`1. New eSF-Project`

``` {class=line-numbers}
File --> New --> eSF Project

Project Name: esf_android
Directory: C:\Users\eit\Documents\eclipse-workspace
SDK Install Dir: C:\_App\les_sdk
Finish
```

# `2. New eSF_Bundle`

``` {class=line-numbers}
Source Project: C:\Users\eit\Documents\eclipse-workspace\esf_android
Bundle Name: esfandroidbundle
Package Name: com.eit.esfandroid
Bundle With: Application, Profile, 6.0 Libraries
Next

Application Name: esf android app
Profile Class Name: MyProfile
Finish
```

``` {class=line-numbers}
```

# `3. Add eSF library`

``` {class=line-numbers}
Right Click at Project --> Build Path --> Add Libraries --> User Library --> esfSDK6.0
Finish
```

# `4. Add CustomPrompt Class`

``` {class=line-numbers}
public class CustomPrompt implements AndroidPrompt;
```