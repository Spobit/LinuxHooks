***
`Reference:`
***
[toc]
***


# `eSF SDK (SDK of Lexmark Embedded Solutions Framework)`

1. Get eSF SDK and Certification from lexmark.
2. Extract "ESS.62.039 and EAST 6.0.1" to C:\\\_App, and change name to les\_sdk.
3. Extract all certifications to C:\\\_App\\les\_sdk\\certifications.
4. Use the certification automatically:
    1. create file **my.properties** in %LES\_SDK%\\tools.
    2. write "generic.cert=C:/\_App/les\_sdk/certifications/<name_of_certification_file>" to the file.
5. Set system environment variables for java:
    | Name | Value |
    |---|---|
    | LES\_SDK | C:\\\_App\\les_sdk |
    | PRINTER_ADDRESS | 192.168.1.239 |

# `Java Development Environment`

1. Download Java 2 Platform, Standard Edition JDK, Version 8
2. Install JDK at C:\\\_App\\Java\\jdk1.8.0\_202.
3. Install JRE at C:\\\_App\\Java\\jre1.8.0\_202.
4. Set system environment variables for java:
    | Name | Value |
    |---|---|
    | JAVA\_HOME | C:\\\_App\\Java\\jdk1.8.0_202 |
    | CLASSPATH | .;%JAVA_HOME%\\lib\\dt.jar;%JAVA_HOME%\\lib\\tools.jar |
    | Path | %JAVA_HOME%\\bin;%JAVA_HOME%\\jre\\bin; |
5. Test:
    1. start cmd
    2. test command **java -version**, **java**, **javac**, **jdb**.

# `Apache Commons Net`

1. Download Apache Commons Net.
2. Extract all commons-net-3.6 to C:\\\_App.

# `Apache Ant`

1. Download Apache Ant that has a edition 1.9.6 or large than that
2. Extract apache-ant-1.10.5 to C:\\\_App.
3. Set system environment variables for Apache Ant:
    | Name | Value |
    |---|---|
    | ANT\_HOME | C:\\\_App\\apache\-ant\-1.10.5 |
    | Path | %ANT_HOME%\\bin; |
4. Test
    1. start cmd
    2. test command **ant -version**.
5. Copy C:\\\_App\\commons-net-3.6\\commons-net-3.6.jar" to %ANT\_HOME%\\lib.

# `Eclipse`

1. Download Eclipse.
2. Select "Eclipse IDE for Jave Developers".
3. Installation Folder: C:\\\_App
4. Accept Now
5. Accept
6. Open eclipse and set Preferences:
    - Colors and Fonts -> Text Font

# `Configure Development Environment of Lexmark`

1. eclipse:

    - Copy "C:\\\_App\\les_sdk\\eclipsePlugin\\com.lexmark.prtapp.tools.plugin.jar" to "C:\\\_App\eclipse\\eclipse\\dropins".

    - Window -> Preferences -> Ant -> Runtime -> Ant Home: "C:\\\_App\\apache-ant-1.10.5".

    - Window -> Preferences -> Java -> Code Style -> Formatter -> Import: "C:\\\_App\\les\_sdk\\tools\\esfStandards.xml".

    - Window -> Preferences -> Java -> Build Path -> User Libraries -> New: "esfSDK6.0".

    - Window -> Preferences -> Java -> Build Path -> User Libraries -> Add External JARs: "C:\\\_App\\les\_sdk\\lib6", select all jars -> Open -> Apply and Close.

# `Create application`

1. New eSF Project

2. New eSF bundle

3. Window -> Show View -> Ant

4. Ant View -> Add Buildfiles

5. flash to building and installation, or, build_falsh to building.
