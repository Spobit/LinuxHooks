***
[TOC]
***

# `Install`

``` {class=line-numbers}
$ sudo pacman -S i3

$ sudo vim ~/.xinitrc

# twm &
# xclock -geometry 50*50-1+1 &
# xterm -geometry 80*50+494+51 &
# xterm -geometry 80*20+494-1 &
# exec xterm -geometry 80*60+0+0 -name login

# exec i3 when exec startx
exec i3
```

# `Configure`

``` {class=line-numbers}
```