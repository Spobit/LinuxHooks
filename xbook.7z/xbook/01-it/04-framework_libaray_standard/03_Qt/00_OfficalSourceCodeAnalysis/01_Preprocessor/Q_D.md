```
#define Q_D(Class) Class##Private * const d = d_func()
```